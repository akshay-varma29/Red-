import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import {
  X,
  Calendar,
  Clock,
  Star,
  CheckCircle2,
  DollarSign,
  Send,
  User,
  ShieldCheck
} from 'lucide-react';

export const TrainerBookingModal: React.FC = () => {
  const {
    selectedTrainerForBooking,
    setSelectedTrainerForBooking,
    bookTrainerSession,
    currentUser
  } = useGym();

  const [date, setDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });

  const [time, setTime] = useState('09:00 AM');
  const [notes, setNotes] = useState('Focus on barbell mechanics and individualized strength periodization.');

  if (!selectedTrainerForBooking) return null;
  const trainer = selectedTrainerForBooking;

  const timeSlots = [
    '06:00 AM',
    '07:30 AM',
    '09:00 AM',
    '10:30 AM',
    '01:00 PM',
    '03:30 PM',
    '05:00 PM',
    '06:30 PM',
    '08:00 PM'
  ];

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    bookTrainerSession(trainer.id, date, time, notes);
  };

  return (
    <div
      id="trainer-booking-modal-overlay"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
    >
      <div className="bg-[#141414] border border-neutral-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl space-y-6">
        {/* Close Button */}
        <button
          id="trainer-booking-close-btn"
          onClick={() => setSelectedTrainerForBooking(null)}
          className="absolute top-5 right-5 p-2 rounded-xl text-neutral-400 hover:text-white bg-black border border-neutral-800 transition-colors cursor-pointer"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with Trainer Snapshot */}
        <div className="flex items-center gap-4 border-b border-neutral-800 pb-5">
          <img
            src={trainer.image}
            alt={trainer.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-[#CCFF00] shrink-0"
          />
          <div>
            <div className="flex items-center gap-1.5 text-xs text-[#CCFF00] font-black mb-0.5">
              <Star className="w-3.5 h-3.5 fill-[#CCFF00]" />
              <span>{trainer.rating.toFixed(1)} ({trainer.reviewsCount} reviews)</span>
            </div>
            <h3 className="font-heading text-2xl sm:text-3xl font-black uppercase text-white leading-none">
              {trainer.name}
            </h3>
            <p className="text-xs text-neutral-400 font-bold uppercase tracking-wider">{trainer.specialization}</p>
          </div>
        </div>

        {/* Pricing Badge */}
        <div className="p-3.5 rounded-xl bg-black border border-neutral-800 flex items-center justify-between text-xs">
          <span className="text-neutral-400 font-bold uppercase">Session Rate (60 mins):</span>
          <span className="font-mono font-bold text-[#CCFF00] text-base">₹{trainer.hourlyRate.toLocaleString('en-IN')} / hr</span>
        </div>

        {/* Booking Form */}
        <form onSubmit={handleBookingSubmit} className="space-y-4">
          {/* Date Picker */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
              Select Session Date
            </label>
            <div className="relative">
              <Calendar className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3.5" />
              <input
                type="date"
                required
                value={date}
                min={new Date().toISOString().split('T')[0]}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-black border border-neutral-800 rounded-xl pl-10 pr-4 py-3 text-xs font-bold text-white focus:border-[#CCFF00] focus:outline-none cursor-pointer"
              />
            </div>
          </div>

          {/* Time Slot Pills */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
              Select Preferred Time
            </label>
            <div className="grid grid-cols-3 gap-2">
              {timeSlots.map((slot) => (
                <button
                  key={slot}
                  type="button"
                  onClick={() => setTime(slot)}
                  className={`py-2 rounded-xl text-xs font-mono font-black transition-colors cursor-pointer ${
                    time === slot
                      ? 'bg-[#CCFF00] text-black'
                      : 'bg-black text-neutral-400 hover:text-white border border-neutral-800'
                  }`}
                >
                  {slot}
                </button>
              ))}
            </div>
          </div>

          {/* Goals / Notes */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
              Specific Goals / Focus Area
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Squat biomechanics, knee rehab, or nutritional strategy..."
              className="w-full bg-black border border-neutral-800 rounded-xl p-3 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none resize-none leading-relaxed font-medium"
            />
          </div>

          {/* Confirm Button */}
          <button
            id="trainer-booking-confirm-btn"
            type="submit"
            className="w-full py-4 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-xl font-black uppercase tracking-wider transition-all shadow-lg shadow-[#CCFF00]/20 cursor-pointer flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-5 h-5" />
            <span>Confirm 1-on-1 Reservation</span>
          </button>
        </form>
      </div>
    </div>
  );
};
