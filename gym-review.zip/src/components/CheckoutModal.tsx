import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import {
  X,
  CreditCard,
  CheckCircle2,
  Lock,
  Zap,
  ShieldCheck,
  Crown
} from 'lucide-react';

export const CheckoutModal: React.FC = () => {
  const {
    selectedPlanForCheckout,
    setSelectedPlanForCheckout,
    joinMembership,
    currentUser
  } = useGym();

  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8821');
  const [cardExpiry, setCardExpiry] = useState('08/29');
  const [cardCvc, setCardCvc] = useState('784');
  const [cardName, setCardName] = useState(currentUser?.name || 'Brandon Cole');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!selectedPlanForCheckout) return null;
  const plan = selectedPlanForCheckout;

  const price = billingCycle === 'annual' ? plan.priceAnnual : plan.priceMonthly;

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      joinMembership(plan.id, billingCycle);
      setIsProcessing(false);
    }, 600);
  };

  return (
    <div
      id="checkout-modal-overlay"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
    >
      <div className="bg-[#141414] border border-neutral-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl space-y-6">
        {/* Close Button */}
        <button
          id="checkout-modal-close-btn"
          onClick={() => setSelectedPlanForCheckout(null)}
          className="absolute top-5 right-5 p-2 rounded-xl text-neutral-400 hover:text-white bg-black border border-neutral-800 transition-colors cursor-pointer"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-black text-[#CCFF00] uppercase tracking-widest">
            <Crown className="w-4 h-4" /> Membership Pass Activation
          </div>
          <h3 className="font-heading text-3xl sm:text-4xl font-black uppercase text-white tracking-wide">
            JOIN AS <span className="text-[#CCFF00]">{plan.name} MEMBER</span>
          </h3>
          <p className="text-xs text-neutral-400">
            Instant 24/7 keycard activation upon checkout completion.
          </p>
        </div>

        {/* Billing Cycle Selector */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-black rounded-xl border border-neutral-800">
          <button
            type="button"
            onClick={() => setBillingCycle('monthly')}
            className={`py-2 text-xs font-black uppercase rounded-lg transition-colors cursor-pointer ${
              billingCycle === 'monthly' ? 'bg-[#CCFF00] text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Monthly (₹{plan.priceMonthly.toLocaleString('en-IN')}/mo)
          </button>
          <button
            type="button"
            onClick={() => setBillingCycle('annual')}
            className={`py-2 text-xs font-black uppercase rounded-lg transition-colors cursor-pointer ${
              billingCycle === 'annual' ? 'bg-[#CCFF00] text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Annual (₹{plan.priceAnnual.toLocaleString('en-IN')}/yr • 20% Off)
          </button>
        </div>

        {/* Order Summary Box */}
        <div className="p-4 rounded-2xl bg-black border border-neutral-800 space-y-2 text-xs">
          <div className="flex justify-between text-neutral-300">
            <span className="font-medium">{plan.name} Tier Membership ({billingCycle === 'annual' ? 'Annual Pass' : 'Monthly'}):</span>
            <span className="font-mono font-bold text-white">₹{price.toLocaleString('en-IN')}</span>
          </div>
          <div className="flex justify-between text-neutral-400">
            <span>Facility Initiation & Equipment Access Fee:</span>
            <span className="text-[#CCFF00] font-black uppercase">₹0 (Waived)</span>
          </div>
          <div className="flex justify-between text-neutral-400">
            <span>Star Digital Keycard Setup:</span>
            <span className="text-[#CCFF00] font-black uppercase">Included</span>
          </div>
          <div className="pt-2 border-t border-neutral-800 flex justify-between items-center text-sm font-bold text-white">
            <span>Total Due Today:</span>
            <span className="font-heading text-3xl font-black text-[#CCFF00]">₹{price.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {/* Mock Payment Form */}
        <form onSubmit={handleCheckoutSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
              Cardholder Name
            </label>
            <input
              type="text"
              required
              value={cardName}
              onChange={(e) => setCardName(e.target.value)}
              className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white focus:border-[#CCFF00] focus:outline-none font-medium"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
              Credit / Debit Card Number
            </label>
            <div className="relative">
              <CreditCard className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3" />
              <input
                type="text"
                required
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
                className="w-full bg-black border border-neutral-800 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-white focus:border-[#CCFF00] focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                Expiry Date
              </label>
              <input
                type="text"
                required
                value={cardExpiry}
                onChange={(e) => setCardExpiry(e.target.value)}
                className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs font-mono text-white focus:border-[#CCFF00] focus:outline-none"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                CVC Security Code
              </label>
              <input
                type="text"
                required
                value={cardCvc}
                onChange={(e) => setCardCvc(e.target.value)}
                className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs font-mono text-white focus:border-[#CCFF00] focus:outline-none"
              />
            </div>
          </div>

          {/* Guarantee pill */}
          <div className="flex items-center gap-2 text-[11px] text-neutral-400">
            <ShieldCheck className="w-4 h-4 text-[#CCFF00] shrink-0" />
            <span>Encrypted 256-bit SSL transaction. 30-Day Money-Back Guarantee.</span>
          </div>

          <button
            id="checkout-submit-btn"
            type="submit"
            disabled={isProcessing}
            className="w-full py-4 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-xl font-black uppercase tracking-wider transition-all shadow-lg shadow-[#CCFF00]/25 cursor-pointer flex items-center justify-center gap-2"
          >
            <Zap className="w-5 h-5 fill-black" />
            <span>{isProcessing ? 'Activating Keycard...' : `Authorize ₹${price.toLocaleString('en-IN')} & Activate Membership`}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
