import React from 'react';
import { useGym } from '../context/GymContext';
import { Star, MessageSquare, Quote } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const { testimonials } = useGym();

  return (
    <section className="py-24 bg-[#0A0A0A] border-t border-neutral-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141414] border border-[#CCFF00]/40">
            <MessageSquare className="w-4 h-4 text-[#CCFF00]" />
            <span className="text-xs font-black uppercase tracking-widest text-[#CCFF00]">
              COMMUNITY VOICES
            </span>
          </div>
          <h2 className="font-heading text-4xl sm:text-5xl lg:text-7xl font-black uppercase text-white tracking-tight leading-none">
            PROVEN RESULTS. <span className="text-[#CCFF00]">UNFILTERED REVIEWS.</span>
          </h2>
          <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
            Read how athletes, parents, busy professionals, and everyday fitness enthusiasts forged their best selves at Star Fitness Studio.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((t) => (
            <div
              key={t.id}
              id={`testimonial-card-${t.id}`}
              className="p-6 rounded-3xl bg-[#141414] border border-neutral-800 hover:border-[#CCFF00]/50 transition-all duration-300 flex flex-col justify-between space-y-6 shadow-xl relative group"
            >
              <div className="space-y-4">
                {/* Quote Icon & Stars */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-[#CCFF00] fill-[#CCFF00]" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-neutral-700 group-hover:text-[#CCFF00] transition-colors" />
                </div>

                {/* Review Text */}
                <p className="text-xs text-neutral-300 leading-relaxed italic font-medium">
                  "{t.review}"
                </p>
              </div>

              {/* Author & Achievement Bottom */}
              <div className="space-y-3 pt-4 border-t border-neutral-800">
                <div className="flex items-center gap-3">
                  <img
                    src={t.image}
                    alt={t.name}
                    className="w-10 h-10 rounded-full object-cover border border-[#CCFF00]"
                  />
                  <div>
                    <h4 className="font-heading font-black text-white text-sm uppercase tracking-wide">{t.name}</h4>
                    <p className="text-[10px] text-neutral-400 font-bold uppercase">{t.role}</p>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-black border border-neutral-800 text-[10px] text-[#CCFF00] font-black flex items-center justify-between uppercase">
                  <span>{t.programTaken}</span>
                  <span className="text-neutral-400">{t.achievement}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
