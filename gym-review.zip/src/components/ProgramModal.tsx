import React from 'react';
import { useGym } from '../context/GymContext';
import {
  X,
  Clock,
  Flame,
  Award,
  CheckCircle2,
  Calendar,
  Layers,
  Zap,
  Dumbbell
} from 'lucide-react';

export const ProgramModal: React.FC = () => {
  const {
    selectedProgramForModal,
    setSelectedProgramForModal,
    setSelectedClassForBooking,
    schedule
  } = useGym();

  if (!selectedProgramForModal) return null;
  const prog = selectedProgramForModal;

  const handleBookProgramSession = () => {
    const matchingClass = schedule.find((c) =>
      c.category.toLowerCase().includes(prog.category.toLowerCase()) ||
      c.title.toLowerCase().includes(prog.category.toLowerCase())
    ) || schedule[0];

    setSelectedProgramForModal(null);
    if (matchingClass) {
      setSelectedClassForBooking(matchingClass);
    }
  };

  return (
    <div
      id="program-modal-overlay"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
    >
      <div className="bg-[#141414] border border-neutral-800 rounded-3xl max-w-2xl w-full overflow-hidden relative shadow-2xl space-y-0 my-8">
        {/* Close Button */}
        <button
          id="program-modal-close-btn"
          onClick={() => setSelectedProgramForModal(null)}
          className="absolute top-4 right-4 p-2 rounded-full text-white bg-black/80 hover:bg-neutral-800 border border-neutral-700 z-10 transition-colors cursor-pointer"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Image */}
        <div className="relative h-64 sm:h-72 w-full overflow-hidden">
          <img
            src={prog.image}
            alt={prog.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/40 to-transparent" />
          <div className="absolute bottom-4 left-6 right-6 space-y-1">
            <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#CCFF00] text-black">
              {prog.category} Track • {prog.level}
            </span>
            <h3 className="font-heading text-3xl sm:text-5xl font-black uppercase text-white tracking-wide">
              {prog.title}
            </h3>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[60vh] overflow-y-auto">
          {/* Tagline */}
          <p className="text-sm font-bold text-[#CCFF00] uppercase tracking-wide">
            "{prog.tagline}"
          </p>

          {/* Full description */}
          <div className="space-y-2">
            <h4 className="text-xs font-black text-neutral-400 uppercase tracking-wider">
              Program Curriculum & Science
            </h4>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed font-medium">
              {prog.fullDescription}
            </p>
          </div>

          {/* Specs Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-black border border-neutral-800 text-center">
              <span className="text-[10px] text-neutral-400 uppercase font-black block">Duration</span>
              <span className="font-heading text-2xl font-black text-white">{prog.durationWeeks} Weeks</span>
            </div>
            <div className="p-3 rounded-xl bg-black border border-neutral-800 text-center">
              <span className="text-[10px] text-neutral-400 uppercase font-black block">Session Length</span>
              <span className="font-heading text-2xl font-black text-white">{prog.sessionDurationMins} Mins</span>
            </div>
            <div className="p-3 rounded-xl bg-black border border-neutral-800 text-center">
              <span className="text-[10px] text-neutral-400 uppercase font-black block">Target Burn</span>
              <span className="font-heading text-2xl font-black text-[#CCFF00]">{prog.caloriesBurnEstimate}</span>
            </div>
            <div className="p-3 rounded-xl bg-black border border-neutral-800 text-center">
              <span className="text-[10px] text-neutral-400 uppercase font-black block">Coaching Lead</span>
              <span className="font-heading text-lg font-black text-white truncate block mt-1">{prog.trainerName}</span>
            </div>
          </div>

          {/* Key Benefits */}
          <div className="space-y-2">
            <h4 className="text-xs font-black text-neutral-400 uppercase tracking-wider">
              Adaptations & Outcomes
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {prog.benefits.map((b, idx) => (
                <div key={idx} className="flex items-start gap-2 text-xs text-neutral-200 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-[#CCFF00] shrink-0 mt-0.5" />
                  <span>{b}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Dedicated Equipment */}
          <div className="space-y-2">
            <h4 className="text-xs font-black text-neutral-400 uppercase tracking-wider">
              Facility Equipment Utilized
            </h4>
            <div className="flex flex-wrap gap-2">
              {prog.equipment.map((eq, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 rounded-lg bg-black border border-neutral-800 text-xs text-neutral-300 font-bold uppercase"
                >
                  {eq}
                </span>
              ))}
            </div>
          </div>

          {/* Schedule Summary */}
          <div className="p-4 rounded-xl bg-black border border-neutral-800 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-[#CCFF00]" />
              <div>
                <p className="text-[10px] text-neutral-400 font-black uppercase tracking-wider">Weekly Class Schedule</p>
                <p className="text-xs font-bold text-white font-mono">{prog.scheduleSummary}</p>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button
              id="program-modal-book-btn"
              onClick={handleBookProgramSession}
              className="flex-1 py-4 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-xl font-black uppercase tracking-wider transition-colors shadow-lg shadow-[#CCFF00]/20 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Zap className="w-5 h-5 fill-black" />
              <span>Reserve Class Spot</span>
            </button>
            <button
              onClick={() => setSelectedProgramForModal(null)}
              className="px-6 py-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
