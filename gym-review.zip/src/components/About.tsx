import React, { useState } from 'react';
import {
  Award,
  Sparkles,
  Zap,
  CheckCircle2,
  Dumbbell,
  TrendingUp,
  Droplets,
  Compass
} from 'lucide-react';

export const About: React.FC = () => {
  const [activePillarTab, setActivePillarTab] = useState(0);

  const pillars = [
    {
      id: 'equipment',
      title: 'Biomechanical Machinery',
      subtitle: 'Engineered for human anatomical resistance curves',
      icon: Dumbbell,
      description:
        'We invest in world-class machinery including Prime variable-resistance towers, Arsenal plate-loaded incline machines, and Eleiko Olympic competition bars. This maximizes mechanical tension while sparing your joints and tendons.',
      image: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?q=80&w=1000&auto=format&fit=crop',
      points: [
        'Arsenal Incline & T-Bar Row units',
        'Eleiko IPF-Certified calibrated plates',
        'Woodway non-motorized curve treadmills',
        '10 Dedicated Power Racks & Deadlift Platforms'
      ]
    },
    {
      id: 'trainers',
      title: 'Certified Elite Trainers',
      subtitle: 'Degreed strength coaches and exercise scientists',
      icon: Award,
      description:
        'Every coach on our roster holds recognized master-level credentials (NSCA-CSCS, NASM-PES, Precision Nutrition, Kinesiology degrees). No generic cookie-cutter routines—only evidence-based programming tailored to your physiology.',
      image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=1000&auto=format&fit=crop',
      points: [
        'Individual biomechanical movement screening',
        'Personalized periodization & progressive overload',
        'Macronutrient prescription and accountability',
        'Injury prevention & rehabilitation protocols'
      ]
    },
    {
      id: 'environment',
      title: 'Clean & Welcoming Culture',
      subtitle: 'Hospital-grade hygiene with a high-energy, ego-free community',
      icon: Droplets,
      description:
        'We maintain a pristine, hospital-grade sanitized facility equipped with HEPA air purifiers, continuous equipment cleaning, and luxury amenities including cedar infrared saunas, private rain showers, and organic grooming stations.',
      image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=1000&auto=format&fit=crop',
      points: [
        'Continuous HEPA air filtration & sanitization',
        'Full-spectrum cedar infrared saunas & cold plunges',
        'Keypad digital security lockers & plush towel service',
        'Complimentary high-speed Wi-Fi and electrolyte stations'
      ]
    },
    {
      id: 'progression',
      title: 'Beginner to Pro Progression',
      subtitle: 'Tailored roadmaps that meet you exactly where you are',
      icon: TrendingUp,
      description:
        'Whether you are stepping into a gym for the very first time or preparing for an elite athletic combine, our scalable training frameworks guarantee safe, sustainable, and continuous progression without intimidation.',
      image: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?q=80&w=1000&auto=format&fit=crop',
      points: [
        'Complimentary 1-on-1 initial movement & goal assessment',
        'Clear exercise progressions and form regressions',
        'Bi-weekly InBody 770 body composition tracking',
        'Supportive, uplifting member culture'
      ]
    }
  ];

  return (
    <section id="about" className="py-24 bg-[#0E0E0E] border-t border-neutral-800 relative">
      {/* Background accents */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#CCFF00]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141414] border border-[#CCFF00]/40">
            <Compass className="w-4 h-4 text-[#CCFF00]" />
            <span className="text-xs font-black uppercase tracking-widest text-[#CCFF00]">
              THE STAR FITNESS DIFFERENCE
            </span>
          </div>
          <h2 className="font-heading text-4xl sm:text-5xl lg:text-7xl font-black uppercase text-white tracking-tight leading-none">
            BUILT FOR THOSE WHO <span className="text-[#CCFF00]">REFUSE MEDIOCRITY</span>
          </h2>
          <p className="text-neutral-300 text-base sm:text-lg leading-relaxed">
            Founded in 2014, Star Fitness Studio was born from a singular mission: to eliminate the shortcomings of crowded commercial gyms by providing championship-grade equipment, elite coaching, and an empowering, ego-free community.
          </p>
        </div>

        {/* Mission & Vision Callout Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          <div className="p-8 rounded-3xl bg-[#141414] border border-neutral-800 hover:border-[#CCFF00]/50 transition-all duration-300 relative group">
            <div className="w-12 h-12 rounded-2xl bg-[#1F1F1F] border border-[#CCFF00]/40 flex items-center justify-center mb-6">
              <Zap className="w-6 h-6 text-[#CCFF00]" />
            </div>
            <h3 className="font-heading text-3xl font-black uppercase text-white mb-2 tracking-wide">
              OUR MISSION
            </h3>
            <p className="text-neutral-300 text-sm leading-relaxed">
              To empower individuals of every fitness background with the scientific tools, expert coaching, and electric environment needed to forge lifelong physical strength, mental resilience, and peak vitality.
            </p>
            <div className="mt-4 pt-4 border-t border-neutral-800 flex items-center gap-2 text-xs font-black text-[#CCFF00] uppercase tracking-wider">
              <span>Performance Driven</span> • <span>Science Backed</span>
            </div>
          </div>

          <div className="p-8 rounded-3xl bg-[#141414] border border-neutral-800 hover:border-white/40 transition-all duration-300 relative group">
            <div className="w-12 h-12 rounded-2xl bg-[#1F1F1F] border border-neutral-700 flex items-center justify-center mb-6">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-heading text-3xl font-black uppercase text-white mb-2 tracking-wide">
              OUR VISION
            </h3>
            <p className="text-neutral-300 text-sm leading-relaxed">
              To become the global benchmark for boutique athletic training by setting new standards in equipment innovation, coaching integrity, recovery science, and transformative member outcomes.
            </p>
            <div className="mt-4 pt-4 border-t border-neutral-800 flex items-center gap-2 text-xs font-black text-neutral-200 uppercase tracking-wider">
              <span>Zero Excuses</span> • <span>Unstoppable Progress</span>
            </div>
          </div>
        </div>

        {/* Why Choose Us - Interactive Pillars Showcase */}
        <div className="space-y-8">
          <div className="text-center">
            <h3 className="font-heading text-3xl sm:text-5xl font-black uppercase text-white tracking-tight">
              WHY TRAIN AT <span className="text-[#CCFF00]">STAR FITNESS STUDIO?</span>
            </h3>
            <p className="text-neutral-400 text-sm mt-2 font-medium">
              Select a pillar below to explore our facility standards and training methodology.
            </p>
          </div>

          {/* Pillar Selector Tabs */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {pillars.map((pillar, idx) => {
              const Icon = pillar.icon;
              const isActive = activePillarTab === idx;
              return (
                <button
                  key={pillar.id}
                  id={`about-pillar-tab-${pillar.id}`}
                  onClick={() => setActivePillarTab(idx)}
                  className={`p-4 rounded-2xl border text-left transition-all duration-200 cursor-pointer flex items-center gap-3 ${
                    isActive
                      ? 'bg-[#1A1A1A] border-[#CCFF00] shadow-lg shadow-[#CCFF00]/10 ring-1 ring-[#CCFF00]'
                      : 'bg-[#141414] border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isActive ? 'bg-[#CCFF00] text-black font-bold' : 'bg-[#1F1F1F] text-neutral-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className={`text-xs sm:text-sm font-black uppercase tracking-wider ${isActive ? 'text-white' : 'text-neutral-300'}`}>
                      {pillar.title}
                    </h4>
                    <p className="text-[10px] text-neutral-400 line-clamp-1 hidden sm:block">
                      {pillar.subtitle}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Pillar Detailed View */}
          {pillars[activePillarTab] && (
            <div className="rounded-3xl bg-[#141414] border border-neutral-800 overflow-hidden shadow-2xl p-6 sm:p-8 lg:p-10">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                {/* Left details */}
                <div className="lg:col-span-7 space-y-6">
                  <div className="space-y-2">
                    <span className="text-xs font-black text-[#CCFF00] uppercase tracking-widest">
                      PILLAR 0{activePillarTab + 1} OF 04
                    </span>
                    <h3 className="font-heading text-3xl sm:text-4xl font-black uppercase text-white tracking-tight">
                      {pillars[activePillarTab].title}
                    </h3>
                    <p className="text-sm font-semibold text-[#CCFF00]">
                      {pillars[activePillarTab].subtitle}
                    </p>
                  </div>

                  <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
                    {pillars[activePillarTab].description}
                  </p>

                  {/* Bullet Checklist */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    {pillars[activePillarTab].points.map((pt, i) => (
                      <div key={i} className="flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-[#CCFF00] shrink-0 mt-0.5" />
                        <span className="text-xs font-bold text-neutral-200">{pt}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-4 flex items-center gap-4">
                    <a
                      href="#membership"
                      className="px-6 py-3.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-lg font-black uppercase tracking-wider transition-all inline-block shadow-lg shadow-[#CCFF00]/20"
                    >
                      Experience It in Person
                    </a>
                  </div>
                </div>

                {/* Right image */}
                <div className="lg:col-span-5 relative">
                  <div className="h-64 sm:h-80 lg:h-96 rounded-2xl overflow-hidden border border-neutral-800 relative group">
                    <img
                      src={pillars[activePillarTab].image}
                      alt={pillars[activePillarTab].title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A]/90 via-transparent to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4 p-3 rounded-xl bg-black/85 backdrop-blur-md border border-neutral-800">
                      <p className="text-xs font-black text-white uppercase tracking-wider">
                        {pillars[activePillarTab].title}
                      </p>
                      <p className="text-[11px] text-neutral-400">
                        Inspected & maintained daily by Star Fitness facility staff.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
