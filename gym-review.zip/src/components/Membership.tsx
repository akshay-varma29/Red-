import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import {
  Check,
  X,
  Sparkles,
  Zap,
  ShieldCheck,
  Crown,
  Lock
} from 'lucide-react';

export const Membership: React.FC = () => {
  const { membershipPlans, setSelectedPlanForCheckout, currentUser } = useGym();
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

  return (
    <section id="membership" className="py-24 bg-[#0A0A0A] border-t border-neutral-800 relative">
      {/* Glow highlight */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#CCFF00]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141414] border border-[#CCFF00]/40">
            <Crown className="w-4 h-4 text-[#CCFF00]" />
            <span className="text-xs font-black uppercase tracking-widest text-[#CCFF00]">
              TRANSPARENT MEMBERSHIP TIERS
            </span>
          </div>
          <h2 className="font-heading text-4xl sm:text-5xl lg:text-7xl font-black uppercase text-white tracking-tight leading-none">
            INVEST IN YOUR <span className="text-[#CCFF00]">TRANSFORMATION</span>
          </h2>
          <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
            Zero lock-in contracts. No hidden sign-up or maintenance fees.
            Select the plan that matches your training cadence and unlock your potential.
          </p>

          {/* Billing Cycle Toggle */}
          <div className="pt-4 flex items-center justify-center gap-4">
            <div className="bg-[#141414] p-1.5 rounded-2xl border border-neutral-800 flex items-center gap-1">
              <button
                id="billing-toggle-monthly"
                onClick={() => setBillingCycle('monthly')}
                className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer ${
                  billingCycle === 'monthly'
                    ? 'bg-[#CCFF00] text-black shadow-md'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                Monthly Billing
              </button>
              <button
                id="billing-toggle-annual"
                onClick={() => setBillingCycle('annual')}
                className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 flex items-center gap-1.5 cursor-pointer ${
                  billingCycle === 'annual'
                    ? 'bg-[#CCFF00] text-black shadow-md'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <span>Annual Billing</span>
                <span className="px-1.5 py-0.5 rounded bg-red-600 text-white text-[9px] font-black tracking-normal">
                  SAVE 20%
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch mb-16">
          {membershipPlans.map((plan) => {
            const isUserCurrentPlan = currentUser?.membershipPlanId === plan.id;
            const price = billingCycle === 'annual' ? Math.round(plan.priceAnnual / 12) : plan.priceMonthly;
            const totalAnnualPrice = plan.priceAnnual;

            return (
              <div
                key={plan.id}
                id={`membership-card-${plan.id}`}
                className={`rounded-3xl bg-[#141414] border transition-all duration-300 flex flex-col justify-between p-8 relative overflow-hidden ${
                  plan.popular
                    ? 'border-[#CCFF00] shadow-2xl shadow-[#CCFF00]/15 lg:-translate-y-3 ring-1 ring-[#CCFF00]/60 bg-gradient-to-b from-[#141414] via-[#141414] to-black'
                    : 'border-neutral-800 hover:border-neutral-700 shadow-xl'
                }`}
              >
                {/* Popular Banner */}
                {plan.popular && (
                  <div className="absolute top-0 right-0">
                    <div className="bg-[#CCFF00] text-black text-[10px] font-black uppercase tracking-widest py-1.5 px-6 rounded-bl-2xl shadow-md flex items-center gap-1">
                      <Sparkles className="w-3 h-3 fill-black" />
                      <span>Most Popular</span>
                    </div>
                  </div>
                )}

                <div>
                  {/* Plan Name & Tagline */}
                  <div className="space-y-2 mb-6">
                    <h3 className="font-heading text-3xl font-black uppercase text-white tracking-tight flex items-center gap-2">
                      {plan.name}
                      {plan.id === 'plan-pro' && <Crown className="w-5 h-5 text-[#CCFF00]" />}
                    </h3>
                    <p className="text-xs text-neutral-300 min-h-[36px] leading-relaxed">
                      {plan.tagline}
                    </p>
                  </div>

                  {/* Price Block */}
                  <div className="mb-6 pb-6 border-b border-neutral-800">
                    <div className="flex items-baseline gap-1">
                      <span className="text-neutral-400 font-bold text-2xl">₹</span>
                      <span className="font-heading text-6xl sm:text-7xl font-black text-white tracking-tight">
                        {price.toLocaleString('en-IN')}
                      </span>
                      <span className="text-xs font-black text-neutral-400 uppercase">
                        / Month
                      </span>
                    </div>
                    {billingCycle === 'annual' ? (
                      <p className="text-xs text-[#CCFF00] font-bold mt-1">
                        Billed annually at ₹{totalAnnualPrice.toLocaleString('en-IN')}/year (Includes 2 Free Months)
                      </p>
                    ) : (
                      <p className="text-xs text-neutral-400 font-medium mt-1">
                        Billed monthly • Cancel anytime
                      </p>
                    )}
                  </div>

                  {/* High-Level Spec Highlights */}
                  <div className="space-y-3 mb-6 text-xs text-neutral-200">
                    <div className="p-3 rounded-xl bg-black/70 border border-neutral-800 space-y-1">
                      <p className="text-[10px] font-black text-[#CCFF00] uppercase tracking-wider">
                        Facility Access
                      </p>
                      <p className="text-neutral-300 font-medium">{plan.trainingAccess}</p>
                    </div>

                    <div className="p-3 rounded-xl bg-black/70 border border-neutral-800 space-y-1">
                      <p className="text-[10px] font-black text-[#CCFF00] uppercase tracking-wider">
                        Personal Coaching
                      </p>
                      <p className="text-neutral-300 font-medium">{plan.personalTrainingSessions}</p>
                    </div>

                    <div className="p-3 rounded-xl bg-black/70 border border-neutral-800 space-y-1">
                      <p className="text-[10px] font-black text-[#CCFF00] uppercase tracking-wider">
                        Group Classes
                      </p>
                      <p className="text-neutral-300 font-medium">{plan.groupClassesAccess}</p>
                    </div>
                  </div>

                  {/* Full Features Checklist */}
                  <div className="space-y-2.5 mb-8">
                    <p className="text-[10px] font-black text-neutral-400 uppercase tracking-widest">
                      What's Included:
                    </p>
                    {plan.features.map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs text-neutral-200">
                        <Check className="w-4 h-4 text-[#CCFF00] shrink-0 mt-0.5" />
                        <span className="leading-snug">{feat}</span>
                      </div>
                    ))}
                    {plan.nonIncludedFeatures && plan.nonIncludedFeatures.map((nFeat, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs text-neutral-500">
                        <X className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
                        <span className="leading-snug line-through">{nFeat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Join CTA Button */}
                <div>
                  <button
                    id={`membership-join-btn-${plan.id}`}
                    onClick={() => setSelectedPlanForCheckout(plan)}
                    className={`w-full py-4 rounded-xl font-heading text-xl font-black uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg ${
                      plan.popular
                        ? 'bg-[#CCFF00] hover:bg-[#b8e600] text-black shadow-[#CCFF00]/30 hover:scale-[1.02]'
                        : 'bg-[#1F1F1F] hover:bg-neutral-800 text-white hover:text-[#CCFF00] border border-neutral-700'
                    }`}
                  >
                    <Zap className="w-5 h-5 fill-current" />
                    <span>{isUserCurrentPlan ? 'Current Plan (Manage)' : `Join as ${plan.name}`}</span>
                  </button>
                  <p className="text-center text-[10px] text-neutral-400 mt-2 flex items-center justify-center gap-1 font-medium">
                    <Lock className="w-3 h-3 text-[#CCFF00]" />
                    <span>Instant Digital Keycard Activation</span>
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Membership Guarantee Footer Banner */}
        <div className="p-6 rounded-2xl bg-[#141414] border border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-300">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-[#CCFF00] shrink-0" />
            <div>
              <p className="font-black text-white uppercase tracking-wide">30-Day Money Back Satisfaction Guarantee</p>
              <p className="text-neutral-400">If you don't feel noticeably stronger and more energized within 30 days, receive a 100% full refund.</p>
            </div>
          </div>
          <a
            href="#contact"
            className="text-[#CCFF00] hover:underline font-bold whitespace-nowrap uppercase tracking-wider"
          >
            Questions? Talk to Member Services →
          </a>
        </div>
      </div>
    </section>
  );
};
