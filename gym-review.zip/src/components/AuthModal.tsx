import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import {
  X,
  User,
  ShieldCheck,
  Lock,
  Mail,
  Star
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    loginAs,
    registerUser
  } = useGym();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regGoal, setRegGoal] = useState('Build Strength & Lean Muscle');

  if (!isAuthModalOpen) return null;

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regEmail) return;
    registerUser(regName, regEmail, regPhone, regGoal);
  };

  return (
    <div
      id="auth-modal-overlay"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
    >
      <div className="bg-[#141414] border border-neutral-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl space-y-6">
        {/* Close Button */}
        <button
          id="auth-modal-close-btn"
          onClick={() => setIsAuthModalOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-xl text-neutral-400 hover:text-white bg-black border border-neutral-800 transition-colors cursor-pointer"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-black border border-[#CCFF00]/40 flex items-center justify-center mx-auto text-[#CCFF00]">
            <Star className="w-6 h-6 fill-[#CCFF00]" />
          </div>
          <h3 className="font-heading text-3xl font-black uppercase text-white tracking-wide">
            STAR FITNESS <span className="text-[#CCFF00]">STUDIO PORTAL</span>
          </h3>
          <p className="text-xs text-neutral-400">
            Access your 24/7 digital keycard pass, class reservations, and personal training schedule.
          </p>
        </div>

        {/* Quick Demo Switchers (High convenience for testing & preview) */}
        <div className="p-4 rounded-2xl bg-black border border-neutral-800 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-[#CCFF00] uppercase tracking-wider">
              ⚡ Quick 1-Click Demo Logins
            </span>
            <span className="text-[10px] text-neutral-500 font-bold uppercase">Instant Access</span>
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            <button
              id="demo-login-member-btn"
              onClick={() => loginAs('member')}
              className="p-3 rounded-xl bg-[#141414] hover:bg-[#1f1f1f] border border-neutral-800 hover:border-[#CCFF00]/60 text-left transition-all group cursor-pointer"
            >
              <div className="flex items-center gap-2 mb-1">
                <User className="w-4 h-4 text-[#CCFF00]" />
                <span className="text-xs font-black uppercase text-white group-hover:text-[#CCFF00] transition-colors">
                  Demo Member
                </span>
              </div>
              <p className="text-[10px] text-neutral-400">Brandon Cole (Premium Pass)</p>
            </button>

            <button
              id="demo-login-admin-btn"
              onClick={() => loginAs('admin')}
              className="p-3 rounded-xl bg-red-950/40 hover:bg-red-950/80 border border-red-900/60 hover:border-red-500 text-left transition-all group cursor-pointer"
            >
              <div className="flex items-center gap-2 mb-1">
                <ShieldCheck className="w-4 h-4 text-red-400" />
                <span className="text-xs font-black uppercase text-white group-hover:text-red-300 transition-colors">
                  Demo Admin
                </span>
              </div>
              <p className="text-[10px] text-neutral-400">Coach Vance (Gym Manager)</p>
            </button>
          </div>
        </div>

        {/* Mode Selector */}
        <div className="flex rounded-xl bg-black p-1 border border-neutral-800">
          <button
            onClick={() => setMode('login')}
            className={`w-1/2 py-2 text-xs font-black uppercase rounded-lg transition-colors cursor-pointer ${
              mode === 'login' ? 'bg-[#CCFF00] text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => setMode('register')}
            className={`w-1/2 py-2 text-xs font-black uppercase rounded-lg transition-colors cursor-pointer ${
              mode === 'register' ? 'bg-[#CCFF00] text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Create Account
          </button>
        </div>

        {/* Login Mode View */}
        {mode === 'login' ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              loginAs('member');
            }}
            className="space-y-4"
          >
            <div className="space-y-1.5">
              <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3.5" />
                <input
                  type="email"
                  required
                  defaultValue="member@starfitness.com"
                  placeholder="name@example.com"
                  className="w-full bg-black border border-neutral-800 rounded-xl pl-10 pr-4 py-3 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none font-medium"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3.5" />
                <input
                  type="password"
                  required
                  defaultValue="••••••••"
                  placeholder="••••••••"
                  className="w-full bg-black border border-neutral-800 rounded-xl pl-10 pr-4 py-3 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none font-medium"
                />
              </div>
            </div>

            <button
              id="auth-submit-login-btn"
              type="submit"
              className="w-full py-3.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-lg font-black uppercase tracking-wider transition-colors shadow-lg shadow-[#CCFF00]/20 cursor-pointer"
            >
              Sign In to Studio
            </button>
          </form>
        ) : (
          /* Register Mode View */
          <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
            <div className="space-y-1">
              <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                Full Name
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Jordan Martinez"
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none font-medium"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                  Email
                </label>
                <input
                  type="email"
                  required
                  placeholder="jordan@example.com"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none font-medium"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                  Phone
                </label>
                <input
                  type="tel"
                  placeholder="(555) 000-0000"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none font-medium"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                Primary Fitness Goal
              </label>
              <select
                value={regGoal}
                onChange={(e) => setRegGoal(e.target.value)}
                className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white focus:border-[#CCFF00] focus:outline-none font-bold"
              >
                <option value="Build Strength & Lean Muscle">Build Strength & Lean Muscle</option>
                <option value="Fat Loss & Body Recomposition">Fat Loss & Body Recomposition</option>
                <option value="High-Octane Cardio & VO2 Max">High-Octane Cardio & VO2 Max</option>
                <option value="Olympic Powerlifting & 1RM Gains">Olympic Powerlifting & 1RM Gains</option>
                <option value="Mobility & Injury Rehabilitation">Mobility & Injury Rehabilitation</option>
              </select>
            </div>

            <button
              id="auth-submit-register-btn"
              type="submit"
              className="w-full py-3.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-lg font-black uppercase tracking-wider transition-all shadow-lg shadow-[#CCFF00]/20 cursor-pointer"
            >
              Create Member Account
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
