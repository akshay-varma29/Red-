import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import {
  Image as ImageIcon,
  Maximize2,
  X,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  CheckCircle2
} from 'lucide-react';

export const Gallery: React.FC = () => {
  const { gallery } = useGym();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeLightboxIndex, setActiveLightboxIndex] = useState<number | null>(null);

  const categories = [
    { id: 'all', label: 'All Photos' },
    { id: 'workouts', label: 'Workouts' },
    { id: 'equipment', label: 'Bio Equipment' },
    { id: 'sessions', label: '1-on-1 Sessions' },
    { id: 'classes', label: 'Group Classes' },
    { id: 'environment', label: 'Gym Environment' }
  ];

  const filteredGallery = gallery.filter(
    (item) => activeCategory === 'all' || item.category === activeCategory
  );

  const handleNextLightbox = () => {
    if (activeLightboxIndex === null) return;
    setActiveLightboxIndex((activeLightboxIndex + 1) % filteredGallery.length);
  };

  const handlePrevLightbox = () => {
    if (activeLightboxIndex === null) return;
    setActiveLightboxIndex((activeLightboxIndex - 1 + filteredGallery.length) % filteredGallery.length);
  };

  const transformations = [
    {
      name: 'Marcus Hayes',
      timeframe: '16 Weeks',
      stats: '-28 lbs Fat • +12 lbs Muscle',
      quote: 'The structured hypertrophy splits and Marcus Vance\'s coaching completely changed my life.',
      image: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?q=80&w=600&auto=format&fit=crop'
    },
    {
      name: 'Jessica Lin',
      timeframe: '12 Weeks',
      stats: 'Body Fat: 31% → 20%',
      quote: 'Elena\'s nutrition plan was so easy to follow, and the HIIT classes became the best part of my day.',
      image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?q=80&w=600&auto=format&fit=crop'
    },
    {
      name: 'Tyler Vance',
      timeframe: '24 Weeks',
      stats: 'Squat 225 → 405 lbs',
      quote: 'Training on calibrated Eleiko bars with high-caliber coaches took my powerlifting to state rank.',
      image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600&auto=format&fit=crop'
    }
  ];

  return (
    <section id="gallery" className="py-24 bg-[#0E0E0E] border-t border-neutral-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141414] border border-[#CCFF00]/40">
            <ImageIcon className="w-4 h-4 text-[#CCFF00]" />
            <span className="text-xs font-black uppercase tracking-widest text-[#CCFF00]">
              FACILITY & ATHLETE SPOTLIGHT
            </span>
          </div>
          <h2 className="font-heading text-4xl sm:text-5xl lg:text-7xl font-black uppercase text-white tracking-tight leading-none">
            INSIDE <span className="text-[#CCFF00]">STAR FITNESS STUDIO</span>
          </h2>
          <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
            Take a visual tour through our world-class training floor, Olympic lifting bays, high-velocity turf tracks, and luxury infrared recovery rooms.
          </p>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
            {categories.map((cat) => (
              <button
                key={cat.id}
                id={`gallery-cat-${cat.id}`}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-[#CCFF00] text-black font-black shadow-md shadow-[#CCFF00]/20'
                    : 'bg-[#141414] text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {filteredGallery.map((item, idx) => (
            <div
              key={item.id}
              id={`gallery-item-${item.id}`}
              onClick={() => setActiveLightboxIndex(idx)}
              className="group relative h-72 rounded-3xl overflow-hidden bg-[#141414] border border-neutral-800 cursor-pointer shadow-lg hover:border-[#CCFF00]/60 hover:shadow-[#CCFF00]/10 transition-all duration-300"
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent opacity-80 group-hover:opacity-95 transition-opacity" />

              {/* Hover Zoom Icon */}
              <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/80 backdrop-blur-md border border-neutral-700 flex items-center justify-center text-[#CCFF00] opacity-0 group-hover:opacity-100 transition-opacity">
                <Maximize2 className="w-4 h-4" />
              </div>

              {/* Description & Title Bottom Overlay */}
              <div className="absolute bottom-0 left-0 right-0 p-4 space-y-1 transform translate-y-1 group-hover:translate-y-0 transition-transform">
                <span className="text-[10px] font-black text-[#CCFF00] uppercase tracking-wider block">
                  {item.category}
                </span>
                <h4 className="text-sm font-black text-white uppercase leading-snug font-heading tracking-wide">
                  {item.title}
                </h4>
                <p className="text-[11px] text-neutral-300 line-clamp-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 font-medium">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Transformation Showcase Header & Cards */}
        <div className="pt-8 border-t border-neutral-800">
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
            <div className="inline-flex items-center gap-1.5 text-xs font-black text-[#CCFF00] uppercase tracking-widest">
              <TrendingUp className="w-4 h-4" /> REAL TRANSFORMATIONS
            </div>
            <h3 className="font-heading text-3xl sm:text-5xl font-black uppercase text-white tracking-tight">
              VERIFIED MEMBER <span className="text-[#CCFF00]">SUCCESS STORIES</span>
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {transformations.map((trans, i) => (
              <div
                key={i}
                className="p-6 rounded-3xl bg-[#141414] border border-neutral-800 flex flex-col justify-between space-y-4 hover:border-[#CCFF00]/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <img
                    src={trans.image}
                    alt={trans.name}
                    className="w-16 h-16 rounded-2xl object-cover border border-[#CCFF00]"
                  />
                  <div>
                    <h4 className="font-heading text-xl font-black uppercase text-white tracking-wide">{trans.name}</h4>
                    <span className="px-2 py-0.5 rounded-md bg-[#1F1F1F] text-[#CCFF00] font-black text-[10px] uppercase border border-[#CCFF00]/30">
                      {trans.timeframe} Transformation
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-black border border-neutral-800 text-center">
                  <p className="font-mono text-sm font-black text-[#CCFF00]">{trans.stats}</p>
                </div>

                <p className="text-xs text-neutral-300 italic leading-relaxed font-medium">
                  "{trans.quote}"
                </p>

                <div className="flex items-center gap-1 text-[11px] text-[#CCFF00] font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Verified Dynamic Hub Member
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Lightbox Modal */}
      {activeLightboxIndex !== null && filteredGallery[activeLightboxIndex] && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4">
          <button
            onClick={() => setActiveLightboxIndex(null)}
            className="absolute top-6 right-6 p-3 rounded-full bg-[#141414] text-neutral-300 hover:text-white border border-neutral-700 z-10 cursor-pointer"
            aria-label="Close Lightbox"
          >
            <X className="w-6 h-6" />
          </button>

          <button
            onClick={handlePrevLightbox}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-[#141414] text-white border border-neutral-700 hover:bg-[#CCFF00] hover:text-black transition-colors z-10 cursor-pointer"
            aria-label="Previous Image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={handleNextLightbox}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-[#141414] text-white border border-neutral-700 hover:bg-[#CCFF00] hover:text-black transition-colors z-10 cursor-pointer"
            aria-label="Next Image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="max-w-4xl w-full max-h-[85vh] flex flex-col items-center">
            <img
              src={filteredGallery[activeLightboxIndex].image}
              alt={filteredGallery[activeLightboxIndex].title}
              className="max-h-[65vh] w-auto object-contain rounded-2xl border border-neutral-800 shadow-2xl"
            />
            <div className="text-center mt-4 max-w-xl space-y-1">
              <h3 className="font-heading text-2xl font-black uppercase text-white">
                {filteredGallery[activeLightboxIndex].title}
              </h3>
              <p className="text-xs text-neutral-300">
                {filteredGallery[activeLightboxIndex].description}
              </p>
              <span className="text-[10px] text-neutral-400 uppercase font-mono block pt-1 font-bold">
                {activeLightboxIndex + 1} of {filteredGallery.length}
              </span>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
