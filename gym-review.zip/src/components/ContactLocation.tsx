import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import {
  MapPin,
  Phone,
  Clock,
  Send,
  CheckCircle2
} from 'lucide-react';

export const ContactLocation: React.FC = () => {
  const { gymInfo, submitContactForm } = useGym();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'General Inquiry / Facility Tour',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    setIsSubmitting(true);
    setTimeout(() => {
      submitContactForm(formData);
      setIsSubmitting(false);
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: 'General Inquiry / Facility Tour',
        message: ''
      });
      setTimeout(() => setSubmitted(false), 5000);
    }, 400);
  };

  return (
    <section id="contact" className="py-24 bg-[#0E0E0E] border-t border-neutral-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141414] border border-[#CCFF00]/40">
            <MapPin className="w-4 h-4 text-[#CCFF00]" />
            <span className="text-xs font-black uppercase tracking-widest text-[#CCFF00]">
              LOCATION & CONTACT
            </span>
          </div>
          <h2 className="font-heading text-4xl sm:text-5xl lg:text-7xl font-black uppercase text-white tracking-tight leading-none">
            CONNECT WITH <span className="text-[#CCFF00]">STAR FITNESS STUDIO</span>
          </h2>
          <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
            Stop by for a facility walkthrough, meet our head coaches, or drop us a note below.
            We respond to all member inquiries within 2 business hours.
          </p>
        </div>

        {/* 2 Column Layout: Info + Map / Contact Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Facility Details & Google Maps Embed */}
          <div className="lg:col-span-5 space-y-6">
            {/* Quick Contact Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
              {/* Address Card */}
              <div className="p-5 rounded-2xl bg-[#141414] border border-neutral-800 flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-black border border-[#CCFF00]/40 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-[#CCFF00]" />
                </div>
                <div>
                  <h4 className="font-heading text-lg font-black uppercase text-white">Facility Address</h4>
                  <p className="text-xs text-neutral-300 mt-0.5">{gymInfo.address}</p>
                  <p className="text-xs text-neutral-400 font-bold">{gymInfo.cityStateZip}</p>
                </div>
              </div>

              {/* Direct Phone & Email */}
              <div className="p-5 rounded-2xl bg-[#141414] border border-neutral-800 flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-black border border-[#CCFF00]/40 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5 text-[#CCFF00]" />
                </div>
                <div>
                  <h4 className="font-heading text-lg font-black uppercase text-white">Direct Line & Inquiries</h4>
                  <p className="text-xs text-neutral-300 mt-0.5 font-mono font-bold">{gymInfo.phone}</p>
                  <p className="text-xs text-neutral-400">{gymInfo.email}</p>
                </div>
              </div>

              {/* Hours Card */}
              <div className="p-5 rounded-2xl bg-[#141414] border border-neutral-800 flex items-start gap-4 sm:col-span-2 lg:col-span-1">
                <div className="w-10 h-10 rounded-xl bg-black border border-[#CCFF00]/40 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5 text-[#CCFF00]" />
                </div>
                <div className="space-y-1 w-full">
                  <h4 className="font-heading text-lg font-black uppercase text-white">Operating Hours</h4>
                  <div className="text-xs text-neutral-300 space-y-1">
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Mon - Fri:</span>
                      <span className="font-bold text-white font-mono">{gymInfo.hoursWeekday}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Saturday:</span>
                      <span className="font-bold text-white font-mono">{gymInfo.hoursSaturday}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Sunday:</span>
                      <span className="font-bold text-white font-mono">{gymInfo.hoursSunday}</span>
                    </div>
                  </div>
                  <div className="pt-2 border-t border-neutral-800 flex items-center gap-1.5 text-[10px] text-[#CCFF00] font-black uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-[#CCFF00] animate-pulse"></span>
                    <span>24/7 Digital Pass Access for Pro Members</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Google Maps Preview Card */}
            <div className="rounded-2xl overflow-hidden border border-neutral-800 bg-black shadow-xl relative h-64 sm:h-72">
              <iframe
                title="Star Fitness Studio Location Map"
                src={gymInfo.mapsEmbedUrl}
                width="100%"
                height="100%"
                style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg) brightness(95%) contrast(90%)' }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
              <div className="absolute top-3 left-3 bg-black/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-neutral-800 text-[11px] font-black text-[#CCFF00] uppercase tracking-wider">
                Downtown Performance Campus
              </div>
            </div>
          </div>

          {/* Right Column: Contact Message Form */}
          <div className="lg:col-span-7 bg-[#141414] border border-neutral-800 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6">
            <div className="space-y-2">
              <h3 className="font-heading text-3xl sm:text-4xl font-black uppercase text-white tracking-wide">
                SEND US A <span className="text-[#CCFF00]">MESSAGE</span>
              </h3>
              <p className="text-xs sm:text-sm text-neutral-300">
                Interested in personal training, group corporate passes, or taking a free facility tour? Drop your details below.
              </p>
            </div>

            {submitted ? (
              <div className="p-8 rounded-2xl bg-emerald-950/50 border border-[#CCFF00]/50 text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-[#CCFF00] mx-auto" />
                <h4 className="font-heading text-2xl font-black uppercase text-white">
                  Message Transmitted!
                </h4>
                <p className="text-xs text-neutral-300 max-w-md mx-auto">
                  Thank you! Our head coaching desk has received your note and will reply via email or phone shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                      Full Name <span className="text-[#CCFF00]">*</span>
                    </label>
                    <input
                      id="contact-name"
                      type="text"
                      required
                      placeholder="e.g. Brandon Cole"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none font-medium"
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                      Email Address <span className="text-[#CCFF00]">*</span>
                    </label>
                    <input
                      id="contact-email"
                      type="email"
                      required
                      placeholder="e.g. brandon@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none font-medium"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Phone */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                      Phone Number
                    </label>
                    <input
                      id="contact-phone"
                      type="tel"
                      placeholder="e.g. (555) 019-2834"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none font-medium"
                    />
                  </div>

                  {/* Subject Dropdown */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                      Topic / Subject
                    </label>
                    <select
                      id="contact-subject"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white focus:border-[#CCFF00] focus:outline-none font-bold"
                    >
                      <option value="General Inquiry / Facility Tour">Facility Tour & Free Day Pass</option>
                      <option value="1-on-1 Personal Training">1-on-1 Personal Training Consultation</option>
                      <option value="Membership Plan Questions">Membership & Billing Inquiry</option>
                      <option value="Corporate Wellness Package">Corporate Wellness (Teams)</option>
                      <option value="Trainer Coaching Career">Join Coaching Staff / Career</option>
                    </select>
                  </div>
                </div>

                {/* Message Box */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                    Message / Fitness Goals <span className="text-[#CCFF00]">*</span>
                  </label>
                  <textarea
                    id="contact-message"
                    required
                    rows={4}
                    placeholder="Tell us about your fitness goals or questions..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full bg-black border border-neutral-800 rounded-xl p-4 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none resize-none leading-relaxed font-medium"
                  />
                </div>

                <button
                  id="contact-submit-btn"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-xl font-black uppercase tracking-wider transition-all duration-200 shadow-lg shadow-[#CCFF00]/20 hover:scale-[1.01] active:scale-[0.99] cursor-pointer flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  <span>{isSubmitting ? 'Transmitting...' : 'Send Message to Coaching Staff'}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
