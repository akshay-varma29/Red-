import React from 'react';
import { useGym } from '../context/GymContext';
import {
  Award,
  Star,
  Calendar,
  Users,
  Clock
} from 'lucide-react';

export const Trainers: React.FC = () => {
  const { trainers, setSelectedTrainerForBooking } = useGym();

  return (
    <section id="trainers" className="py-24 bg-[#0E0E0E] border-t border-neutral-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141414] border border-[#CCFF00]/40">
            <Award className="w-4 h-4 text-[#CCFF00]" />
            <span className="text-xs font-black uppercase tracking-widest text-[#CCFF00]">
              ELITE COACHING ROSTER
            </span>
          </div>
          <h2 className="font-heading text-4xl sm:text-5xl lg:text-7xl font-black uppercase text-white tracking-tight leading-none">
            MEET OUR <span className="text-[#CCFF00]">MASTER COACHES</span>
          </h2>
          <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
            Our coaching team combines university exercise physiology degrees, collegiate athletic careers,
            and top certifications to engineer your safe, measurable progress.
          </p>
        </div>

        {/* Trainers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {trainers.map((trainer) => (
            <div
              key={trainer.id}
              id={`trainer-card-${trainer.id}`}
              className="rounded-3xl bg-[#141414] border border-neutral-800 hover:border-[#CCFF00]/60 transition-all duration-300 overflow-hidden flex flex-col justify-between group shadow-xl hover:shadow-[#CCFF00]/10 hover:-translate-y-1.5"
            >
              {/* Photo & Badges */}
              <div className="relative h-72 sm:h-80 overflow-hidden">
                <img
                  src={trainer.image}
                  alt={trainer.name}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/20 to-transparent" />

                {/* Rating Badge */}
                <div className="absolute top-3 left-3 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/85 backdrop-blur-md border border-neutral-700">
                  <Star className="w-3.5 h-3.5 text-[#CCFF00] fill-[#CCFF00]" />
                  <span className="text-xs font-black text-white">{trainer.rating.toFixed(1)}</span>
                  <span className="text-[10px] text-neutral-400">({trainer.reviewsCount})</span>
                </div>

                {/* Experience Badge */}
                <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-[#CCFF00] text-black font-black text-[10px] uppercase tracking-wider">
                  {trainer.experience}
                </div>

                {/* Social & Clients Mini Bar */}
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between px-3 py-1.5 rounded-xl bg-black/80 backdrop-blur-md border border-neutral-800 text-[11px] font-bold text-neutral-300">
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5 text-[#CCFF00]" />
                    {trainer.clientCount}+ Coached
                  </span>
                  <span className="text-[#CCFF00] font-mono font-bold">₹{trainer.hourlyRate.toLocaleString('en-IN')}/hr</span>
                </div>
              </div>

              {/* Bio & Details */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <h3 className="font-heading text-2xl font-black uppercase text-white tracking-tight group-hover:text-[#CCFF00] transition-colors">
                    {trainer.name}
                  </h3>
                  <p className="text-xs font-black text-[#CCFF00] uppercase tracking-wider">
                    {trainer.specialization}
                  </p>
                  <p className="text-xs text-neutral-300 line-clamp-3 leading-relaxed">
                    {trainer.bio}
                  </p>
                </div>

                {/* Certifications tags */}
                <div className="space-y-1.5 pt-2 border-t border-neutral-800">
                  <p className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                    Credentials
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {trainer.certifications.map((cert, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-md bg-[#1F1F1F] text-neutral-300 text-[10px] font-bold border border-neutral-800"
                      >
                        {cert}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Available Days */}
                <div className="text-[11px] text-neutral-400 flex items-center gap-1.5 font-medium">
                  <Clock className="w-3.5 h-3.5 text-[#CCFF00] shrink-0" />
                  <span className="truncate">
                    Available: {trainer.availableDays.join(', ')}
                  </span>
                </div>

                {/* Action CTA */}
                <div className="pt-2">
                  <button
                    id={`book-trainer-btn-${trainer.id}`}
                    onClick={() => setSelectedTrainerForBooking(trainer)}
                    className="w-full py-3 rounded-xl bg-[#1F1F1F] hover:bg-[#CCFF00] text-white hover:text-black font-heading text-base font-black uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer group-hover:bg-[#CCFF00] group-hover:text-black shadow-md"
                  >
                    <Calendar className="w-4 h-4" />
                    <span>Book a Session</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
