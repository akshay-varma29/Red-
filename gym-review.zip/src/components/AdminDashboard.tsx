import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import { Program, Trainer, ClassScheduleItem, MembershipPlan, DayOfWeek } from '../types';
import {
  X,
  ShieldCheck,
  Dumbbell,
  Users,
  Calendar,
  CreditCard,
  MessageSquare,
  Building,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  Clock,
  MapPin,
  Flame,
  Award,
  DollarSign,
  Save,
  Search
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    isAdminDashboardOpen,
    setIsAdminDashboardOpen,
    programs,
    addProgram,
    updateProgram,
    deleteProgram,
    trainers,
    addTrainer,
    updateTrainer,
    deleteTrainer,
    schedule,
    addClassSchedule,
    updateClassSchedule,
    deleteClassSchedule,
    membershipPlans,
    updateMembershipPlan,
    members,
    updateMemberStatus,
    bookings,
    cancelBooking,
    messages,
    markMessageStatus,
    deleteMessage,
    gymInfo,
    updateGymInfo
  } = useGym();

  const [activeSection, setActiveSection] = useState<
    'programs' | 'trainers' | 'schedule' | 'memberships' | 'members' | 'bookings' | 'messages' | 'facility'
  >('programs');

  // Modals inside Admin
  const [editingProgram, setEditingProgram] = useState<Program | null>(null);
  const [isAddingProgram, setIsAddingProgram] = useState(false);

  const [editingTrainer, setEditingTrainer] = useState<Trainer | null>(null);
  const [isAddingTrainer, setIsAddingTrainer] = useState(false);

  const [editingScheduleItem, setEditingScheduleItem] = useState<ClassScheduleItem | null>(null);
  const [isAddingScheduleItem, setIsAddingScheduleItem] = useState(false);

  // Search filter in members
  const [memberSearch, setMemberSearch] = useState('');

  // Facility Info Form State
  const [facilityForm, setFacilityForm] = useState(gymInfo);

  if (!isAdminDashboardOpen) return null;

  const days: DayOfWeek[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const filteredMembers = members.filter(
    (m) =>
      m.name.toLowerCase().includes(memberSearch.toLowerCase()) ||
      m.email.toLowerCase().includes(memberSearch.toLowerCase())
  );

  return (
    <div
      id="admin-dashboard-overlay"
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
    >
      <div className="bg-[#141414] border border-neutral-800 rounded-3xl max-w-6xl w-full max-h-[92vh] flex flex-col relative shadow-2xl overflow-hidden my-4">
        {/* Top Header */}
        <div className="p-5 border-b border-neutral-800 bg-black flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-950/80 border border-red-700/80 flex items-center justify-center text-red-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-heading text-2xl sm:text-3xl font-black uppercase text-white">
                  GYM MANAGEMENT CONSOLE
                </h3>
                <span className="px-2 py-0.5 rounded bg-red-600 text-white text-[9px] font-black uppercase tracking-wider">
                  Admin Master
                </span>
              </div>
              <p className="text-xs text-neutral-400 font-medium">
                Star Fitness Studio Operations • Live Database Management
              </p>
            </div>
          </div>

          <button
            id="admin-dashboard-close-btn"
            onClick={() => setIsAdminDashboardOpen(false)}
            className="p-2.5 rounded-xl text-neutral-400 hover:text-white bg-[#141414] border border-neutral-800 transition-colors cursor-pointer"
            aria-label="Close Admin Console"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Admin Navigation Tabs */}
        <div className="flex border-b border-neutral-800 bg-black px-4 overflow-x-auto gap-2 scrollbar-none py-2">
          <button
            onClick={() => setActiveSection('programs')}
            className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSection === 'programs'
                ? 'bg-[#CCFF00] text-black shadow-md shadow-[#CCFF00]/20'
                : 'text-neutral-400 hover:text-white hover:bg-[#141414]'
            }`}
          >
            <Dumbbell className="w-4 h-4" />
            <span>Programs ({programs.length})</span>
          </button>

          <button
            onClick={() => setActiveSection('trainers')}
            className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSection === 'trainers'
                ? 'bg-[#CCFF00] text-black shadow-md shadow-[#CCFF00]/20'
                : 'text-neutral-400 hover:text-white hover:bg-[#141414]'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Trainers ({trainers.length})</span>
          </button>

          <button
            onClick={() => setActiveSection('schedule')}
            className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSection === 'schedule'
                ? 'bg-[#CCFF00] text-black shadow-md shadow-[#CCFF00]/20'
                : 'text-neutral-400 hover:text-white hover:bg-[#141414]'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Timetable ({schedule.length})</span>
          </button>

          <button
            onClick={() => setActiveSection('memberships')}
            className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSection === 'memberships'
                ? 'bg-[#CCFF00] text-black shadow-md shadow-[#CCFF00]/20'
                : 'text-neutral-400 hover:text-white hover:bg-[#141414]'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Plans ({membershipPlans.length})</span>
          </button>

          <button
            onClick={() => setActiveSection('members')}
            className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSection === 'members'
                ? 'bg-[#CCFF00] text-black shadow-md shadow-[#CCFF00]/20'
                : 'text-neutral-400 hover:text-white hover:bg-[#141414]'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Members ({members.length})</span>
          </button>

          <button
            onClick={() => setActiveSection('bookings')}
            className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSection === 'bookings'
                ? 'bg-[#CCFF00] text-black shadow-md shadow-[#CCFF00]/20'
                : 'text-neutral-400 hover:text-white hover:bg-[#141414]'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Bookings ({bookings.length})</span>
          </button>

          <button
            onClick={() => setActiveSection('messages')}
            className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSection === 'messages'
                ? 'bg-[#CCFF00] text-black shadow-md shadow-[#CCFF00]/20'
                : 'text-neutral-400 hover:text-white hover:bg-[#141414]'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Inquiries ({messages.length})</span>
          </button>

          <button
            onClick={() => setActiveSection('facility')}
            className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSection === 'facility'
                ? 'bg-[#CCFF00] text-black shadow-md shadow-[#CCFF00]/20'
                : 'text-neutral-400 hover:text-white hover:bg-[#141414]'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>Gym Info</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* 1. PROGRAMS MANAGEMENT */}
          {activeSection === 'programs' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-heading text-2xl font-black uppercase text-white">
                    Program Catalog
                  </h4>
                  <p className="text-xs text-neutral-400 font-medium">Add, adjust curriculum descriptions, and manage fitness tracks.</p>
                </div>
                <button
                  onClick={() => setIsAddingProgram(true)}
                  className="px-4 py-2.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer shadow-lg shadow-[#CCFF00]/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Program</span>
                </button>
              </div>

              {/* Add / Edit Program Drawer Form */}
              {(isAddingProgram || editingProgram) && (
                <div className="p-6 rounded-2xl bg-black border border-[#CCFF00]/50 space-y-4">
                  <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                    <h5 className="font-heading text-xl font-black uppercase text-white">
                      {editingProgram ? `Edit Program: ${editingProgram.title}` : 'Create New Training Program'}
                    </h5>
                    <button
                      onClick={() => {
                        setIsAddingProgram(false);
                        setEditingProgram(null);
                      }}
                      className="text-neutral-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.target as HTMLFormElement;
                      const formData = new FormData(form);

                      const title = formData.get('title') as string;
                      const category = formData.get('category') as any;
                      const tagline = formData.get('tagline') as string;
                      const description = formData.get('description') as string;
                      const fullDescription = formData.get('fullDescription') as string;
                      const level = formData.get('level') as any;
                      const durationWeeks = Number(formData.get('durationWeeks'));
                      const sessionDurationMins = Number(formData.get('sessionDurationMins'));
                      const caloriesBurnEstimate = formData.get('caloriesBurnEstimate') as string;
                      const trainerName = formData.get('trainerName') as string;
                      const trainerRole = formData.get('trainerRole') as string;
                      const image = formData.get('image') as string;
                      const scheduleSummary = formData.get('scheduleSummary') as string;

                      if (editingProgram) {
                        updateProgram(editingProgram.id, {
                          title,
                          category,
                          tagline,
                          description,
                          fullDescription,
                          level,
                          durationWeeks,
                          sessionDurationMins,
                          caloriesBurnEstimate,
                          trainerName,
                          trainerRole,
                          image,
                          scheduleSummary
                        });
                        setEditingProgram(null);
                      } else {
                        addProgram({
                          title,
                          category,
                          tagline,
                          description,
                          fullDescription,
                          level,
                          durationWeeks,
                          sessionDurationMins,
                          caloriesBurnEstimate,
                          trainerName,
                          trainerRole,
                          image,
                          scheduleSummary,
                          benefits: [
                            'Measurable progressive overload & strength adaptations',
                            'Personalized stance & movement mechanics review',
                            'High metabolic activation and conditioning',
                            'Post-workout recovery protocol'
                          ],
                          equipment: ['Eleiko Bars', 'Arsenal Machinery', 'Dumbbells', 'Turf']
                        });
                        setIsAddingProgram(false);
                      }
                    }}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Program Title</label>
                        <input
                          name="title"
                          required
                          defaultValue={editingProgram?.title || ''}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Category</label>
                        <select
                          name="category"
                          defaultValue={editingProgram?.category || 'Strength'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        >
                          {['Strength', 'Weight', 'Cardio', 'Muscle', 'Weight Management', 'Functional', 'Personal', 'Group'].map((c) => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Difficulty Level</label>
                        <select
                          name="level"
                          defaultValue={editingProgram?.level || 'All Levels'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        >
                          {['Beginner', 'Intermediate', 'Advanced', 'All Levels'].map((l) => (
                            <option key={l} value={l}>{l}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-neutral-300 uppercase">Tagline</label>
                      <input
                        name="tagline"
                        required
                        defaultValue={editingProgram?.tagline || ''}
                        className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Short Description</label>
                        <textarea
                          name="description"
                          required
                          rows={2}
                          defaultValue={editingProgram?.description || ''}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-2.5 text-xs text-white resize-none"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Full Science Description</label>
                        <textarea
                          name="fullDescription"
                          required
                          rows={2}
                          defaultValue={editingProgram?.fullDescription || ''}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-2.5 text-xs text-white resize-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Duration (Weeks)</label>
                        <input
                          name="durationWeeks"
                          type="number"
                          defaultValue={editingProgram?.durationWeeks || 8}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Session (Mins)</label>
                        <input
                          name="sessionDurationMins"
                          type="number"
                          defaultValue={editingProgram?.sessionDurationMins || 60}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Est. Calories Burn</label>
                        <input
                          name="caloriesBurnEstimate"
                          defaultValue={editingProgram?.caloriesBurnEstimate || '500 - 700 kcal'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Coach Lead</label>
                        <input
                          name="trainerName"
                          defaultValue={editingProgram?.trainerName || 'Marcus Vance'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Image URL (Unsplash)</label>
                        <input
                          name="image"
                          defaultValue={editingProgram?.image || 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1000&auto=format&fit=crop'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Weekly Schedule Summary</label>
                        <input
                          name="scheduleSummary"
                          defaultValue={editingProgram?.scheduleSummary || 'Mon, Wed, Fri • Morning & Evening'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                    </div>

                    <input type="hidden" name="trainerRole" defaultValue="Master Coach" />

                    <div className="flex justify-end gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingProgram(false);
                          setEditingProgram(null);
                        }}
                        className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold uppercase cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-6 py-2 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black text-xs font-black uppercase shadow-md cursor-pointer transition-colors"
                      >
                        Save Program Record
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Program Rows */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {programs.map((prog) => (
                  <div
                    key={prog.id}
                    className="p-4 rounded-2xl bg-black border border-neutral-800 flex flex-col justify-between space-y-4"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={prog.image}
                        alt={prog.title}
                        className="w-14 h-14 rounded-xl object-cover border border-neutral-800 shrink-0"
                      />
                      <div className="min-w-0">
                        <span className="text-[10px] font-black text-[#CCFF00] uppercase tracking-wider">{prog.category}</span>
                        <h5 className="font-heading text-lg font-black uppercase text-white truncate">{prog.title}</h5>
                        <p className="text-[11px] text-neutral-400 font-medium">{prog.level} • {prog.durationWeeks} wks</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-900">
                      <button
                        onClick={() => setEditingProgram(prog)}
                        className="p-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => deleteProgram(prog.id)}
                        className="p-2 rounded-lg bg-neutral-900 hover:bg-red-950 text-neutral-400 hover:text-red-400 text-xs font-bold cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 2. TRAINERS MANAGEMENT */}
          {activeSection === 'trainers' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-heading text-2xl font-black uppercase text-white">
                    Master Coaches Roster
                  </h4>
                  <p className="text-xs text-neutral-400 font-medium">Manage coach biographies, hourly rates, and credentials.</p>
                </div>
                <button
                  onClick={() => setIsAddingTrainer(true)}
                  className="px-4 py-2.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer shadow-lg shadow-[#CCFF00]/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Trainer</span>
                </button>
              </div>

              {/* Trainer form */}
              {(isAddingTrainer || editingTrainer) && (
                <div className="p-6 rounded-2xl bg-black border border-[#CCFF00]/50 space-y-4">
                  <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                    <h5 className="font-heading text-xl font-black uppercase text-white">
                      {editingTrainer ? `Edit Trainer: ${editingTrainer.name}` : 'Add Master Coach'}
                    </h5>
                    <button
                      onClick={() => {
                        setIsAddingTrainer(false);
                        setEditingTrainer(null);
                      }}
                      className="text-neutral-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.target as HTMLFormElement;
                      const formData = new FormData(form);

                      const name = formData.get('name') as string;
                      const specialization = formData.get('specialization') as string;
                      const experience = formData.get('experience') as string;
                      const bio = formData.get('bio') as string;
                      const hourlyRate = Number(formData.get('hourlyRate'));
                      const image = formData.get('image') as string;
                      const instagram = formData.get('instagram') as string;

                      if (editingTrainer) {
                        updateTrainer(editingTrainer.id, {
                          name,
                          specialization,
                          experience,
                          bio,
                          hourlyRate,
                          image,
                          instagram
                        });
                        setEditingTrainer(null);
                      } else {
                        addTrainer({
                          name,
                          specialization,
                          experience,
                          bio,
                          hourlyRate,
                          image,
                          instagram,
                          rating: 5.0,
                          reviewsCount: 12,
                          clientCount: 20,
                          certifications: ['NASM-CPT', 'Precision Nutrition L1', 'CSCS'],
                          availableDays: ['Monday', 'Wednesday', 'Friday']
                        });
                        setIsAddingTrainer(false);
                      }
                    }}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Coach Name</label>
                        <input
                          name="name"
                          required
                          defaultValue={editingTrainer?.name || ''}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Specialization</label>
                        <input
                          name="specialization"
                          required
                          defaultValue={editingTrainer?.specialization || ''}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Experience (Years)</label>
                        <input
                          name="experience"
                          required
                          defaultValue={editingTrainer?.experience || '8+ Years Experience'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-neutral-300 uppercase">Biography</label>
                      <textarea
                        name="bio"
                        required
                        rows={2}
                        defaultValue={editingTrainer?.bio || ''}
                        className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-2.5 text-xs text-white resize-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Hourly Session Rate ($)</label>
                        <input
                          name="hourlyRate"
                          type="number"
                          required
                          defaultValue={editingTrainer?.hourlyRate || 90}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Instagram Handle</label>
                        <input
                          name="instagram"
                          defaultValue={editingTrainer?.instagram || '@dynamiccoach'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Photo URL</label>
                        <input
                          name="image"
                          defaultValue={editingTrainer?.image || 'https://images.unsplash.com/photo-1567013127542-490d757e51fc?q=80&w=800&auto=format&fit=crop'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingTrainer(false);
                          setEditingTrainer(null);
                        }}
                        className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold uppercase cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-6 py-2 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black text-xs font-black uppercase shadow-md cursor-pointer transition-colors"
                      >
                        Save Coach Record
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Trainers List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {trainers.map((tr) => (
                  <div
                    key={tr.id}
                    className="p-4 rounded-2xl bg-black border border-neutral-800 flex flex-col justify-between space-y-3"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={tr.image}
                        alt={tr.name}
                        className="w-14 h-14 rounded-xl object-cover border border-[#CCFF00]/80 shrink-0"
                      />
                      <div className="min-w-0">
                        <h5 className="font-heading text-lg font-black uppercase text-white truncate">{tr.name}</h5>
                        <p className="text-[10px] text-[#CCFF00] font-bold uppercase truncate">{tr.specialization}</p>
                        <p className="text-xs font-mono text-neutral-300 font-bold">${tr.hourlyRate}/hr</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-900">
                      <button
                        onClick={() => setEditingTrainer(tr)}
                        className="p-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => deleteTrainer(tr.id)}
                        className="p-2 rounded-lg bg-neutral-900 hover:bg-red-950 text-neutral-400 hover:text-red-400 text-xs font-bold cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3. SCHEDULE MANAGEMENT */}
          {activeSection === 'schedule' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-heading text-2xl font-black uppercase text-white">
                    Class Schedule & Timetable
                  </h4>
                  <p className="text-xs text-neutral-400 font-medium">Configure studio rooms, seat capacities, and coach assignments.</p>
                </div>
                <button
                  onClick={() => setIsAddingScheduleItem(true)}
                  className="px-4 py-2.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer shadow-lg shadow-[#CCFF00]/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Class Session</span>
                </button>
              </div>

              {/* Add / Edit schedule item */}
              {(isAddingScheduleItem || editingScheduleItem) && (
                <div className="p-6 rounded-2xl bg-black border border-[#CCFF00]/50 space-y-4">
                  <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                    <h5 className="font-heading text-xl font-black uppercase text-white">
                      {editingScheduleItem ? `Edit Class: ${editingScheduleItem.title}` : 'Add Class to Timetable'}
                    </h5>
                    <button
                      onClick={() => {
                        setIsAddingScheduleItem(false);
                        setEditingScheduleItem(null);
                      }}
                      className="text-neutral-400 hover:text-white cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.target as HTMLFormElement;
                      const formData = new FormData(form);

                      const title = formData.get('title') as string;
                      const category = formData.get('category') as any;
                      const trainerName = formData.get('trainerName') as string;
                      const day = formData.get('day') as any;
                      const startTime = formData.get('startTime') as string;
                      const endTime = formData.get('endTime') as string;
                      const room = formData.get('room') as string;
                      const maxSeats = Number(formData.get('maxSeats'));
                      const intensity = formData.get('intensity') as any;
                      const calorieBurn = formData.get('calorieBurn') as string;

                      if (editingScheduleItem) {
                        updateClassSchedule(editingScheduleItem.id, {
                          title,
                          category,
                          trainerName,
                          day,
                          startTime,
                          endTime,
                          room,
                          maxSeats,
                          intensity,
                          calorieBurn
                        });
                        setEditingScheduleItem(null);
                      } else {
                        addClassSchedule({
                          title,
                          category,
                          trainerName,
                          trainerImage: 'https://images.unsplash.com/photo-1567013127542-490d757e51fc?q=80&w=800&auto=format&fit=crop',
                          day,
                          startTime,
                          endTime,
                          room,
                          maxSeats,
                          intensity,
                          calorieBurn
                        });
                        setIsAddingScheduleItem(false);
                      }
                    }}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Class Title</label>
                        <input
                          name="title"
                          required
                          defaultValue={editingScheduleItem?.title || ''}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Category</label>
                        <select
                          name="category"
                          defaultValue={editingScheduleItem?.category || 'Strength'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        >
                          {['Strength', 'HIIT', 'Functional', 'Boxing', 'Cycling', 'Yoga', 'Cardio'].map((c) => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Day of Week</label>
                        <select
                          name="day"
                          defaultValue={editingScheduleItem?.day || 'Monday'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        >
                          {days.map((d) => (
                            <option key={d} value={d}>{d}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Start Time</label>
                        <input
                          name="startTime"
                          defaultValue={editingScheduleItem?.startTime || '06:30 AM'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">End Time</label>
                        <input
                          name="endTime"
                          defaultValue={editingScheduleItem?.endTime || '07:30 AM'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Max Seats</label>
                        <input
                          name="maxSeats"
                          type="number"
                          defaultValue={editingScheduleItem?.maxSeats || 20}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Intensity</label>
                        <select
                          name="intensity"
                          defaultValue={editingScheduleItem?.intensity || 'High'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        >
                          {['Low', 'Medium', 'High', 'Extreme'].map((i) => (
                            <option key={i} value={i}>{i}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Lead Trainer Name</label>
                        <input
                          name="trainerName"
                          defaultValue={editingScheduleItem?.trainerName || 'Marcus Vance'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Room / Bay</label>
                        <input
                          name="room"
                          defaultValue={editingScheduleItem?.room || 'Main Strength Bay A'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-neutral-300 uppercase">Est. Calorie Burn</label>
                        <input
                          name="calorieBurn"
                          defaultValue={editingScheduleItem?.calorieBurn || '600 kcal'}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingScheduleItem(false);
                          setEditingScheduleItem(null);
                        }}
                        className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold uppercase cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-6 py-2 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black text-xs font-black uppercase shadow-md cursor-pointer transition-colors"
                      >
                        Save Timetable Entry
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Schedule List */}
              <div className="space-y-2">
                {schedule.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-xl bg-black border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-[#CCFF00] text-black font-black text-[10px] uppercase">
                          {item.day}
                        </span>
                        <span className="font-mono text-neutral-300 font-bold">{item.startTime} - {item.endTime}</span>
                        <h5 className="font-heading text-lg font-black uppercase text-white">{item.title}</h5>
                      </div>
                      <div className="flex items-center gap-4 text-neutral-400 font-medium">
                        <span>Coach: <strong className="text-white">{item.trainerName}</strong></span>
                        <span>Room: {item.room}</span>
                        <span>Capacity: {item.bookedSeats} / {item.maxSeats}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 self-end sm:self-auto">
                      <button
                        onClick={() => setEditingScheduleItem(item)}
                        className="p-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white font-bold text-xs flex items-center gap-1 cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => deleteClassSchedule(item.id)}
                        className="p-2 rounded-lg bg-neutral-900 hover:bg-red-950 text-neutral-400 hover:text-red-400 font-bold text-xs cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. MEMBERSHIP PLANS MANAGEMENT */}
          {activeSection === 'memberships' && (
            <div className="space-y-6">
              <div>
                <h4 className="font-heading text-2xl font-black uppercase text-white">
                  Membership Plans & Pricing
                </h4>
                <p className="text-xs text-neutral-400 font-medium">Modify pricing tiers, access terms, and included perks.</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {membershipPlans.map((plan) => (
                  <div
                    key={plan.id}
                    className="p-6 rounded-3xl bg-black border border-neutral-800 space-y-4 flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h5 className="font-heading text-2xl font-black uppercase text-white">{plan.name} Tier</h5>
                        {plan.popular && (
                          <span className="px-2 py-0.5 rounded bg-[#CCFF00] text-black text-[9px] font-black uppercase">
                            Featured
                          </span>
                        )}
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-neutral-400 font-medium">Monthly Price:</span>
                          <div className="flex items-center gap-1">
                            <span className="text-neutral-400 text-xs">$</span>
                            <input
                              type="number"
                              defaultValue={plan.priceMonthly}
                              onBlur={(e) => updateMembershipPlan(plan.id, { priceMonthly: Number(e.target.value) })}
                              className="w-20 bg-neutral-900 border border-neutral-800 rounded-lg px-2 py-1 text-xs text-white font-mono font-bold text-right focus:border-[#CCFF00]"
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-xs text-neutral-400 font-medium">Annual Price:</span>
                          <div className="flex items-center gap-1">
                            <span className="text-neutral-400 text-xs">$</span>
                            <input
                              type="number"
                              defaultValue={plan.priceAnnual}
                              onBlur={(e) => updateMembershipPlan(plan.id, { priceAnnual: Number(e.target.value) })}
                              className="w-20 bg-neutral-900 border border-neutral-800 rounded-lg px-2 py-1 text-xs text-white font-mono font-bold text-right focus:border-[#CCFF00]"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="space-y-1 pt-2 border-t border-neutral-900">
                        <span className="text-[10px] font-black text-[#CCFF00] uppercase tracking-wider">Training Access Summary:</span>
                        <input
                          defaultValue={plan.trainingAccess}
                          onBlur={(e) => updateMembershipPlan(plan.id, { trainingAccess: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-300 focus:border-[#CCFF00]"
                        />
                      </div>

                      <div className="space-y-1">
                        <span className="text-[10px] font-black text-[#CCFF00] uppercase tracking-wider">PT Sessions Summary:</span>
                        <input
                          defaultValue={plan.personalTrainingSessions}
                          onBlur={(e) => updateMembershipPlan(plan.id, { personalTrainingSessions: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-300 focus:border-[#CCFF00]"
                        />
                      </div>
                    </div>

                    <div className="pt-2 text-[10px] text-neutral-500 font-mono">
                      Changes auto-save upon leaving the field.
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. MEMBERS DIRECTORY */}
          {activeSection === 'members' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h4 className="font-heading text-2xl font-black uppercase text-white">
                    Registered Members Directory ({members.length})
                  </h4>
                  <p className="text-xs text-neutral-400 font-medium">View member pass statuses and toggle keycard active states.</p>
                </div>
                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search by name or email..."
                    value={memberSearch}
                    onChange={(e) => setMemberSearch(e.target.value)}
                    className="w-full bg-black border border-neutral-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:border-[#CCFF00] focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-3">
                {filteredMembers.map((m) => (
                  <div
                    key={m.id}
                    className="p-4 rounded-2xl bg-black border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={m.avatar}
                        alt={m.name}
                        className="w-12 h-12 rounded-full object-cover border border-[#CCFF00]/60"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className="font-bold text-white text-sm">{m.name}</h5>
                          <span className="text-[10px] text-neutral-400 font-mono">({m.qrCode})</span>
                        </div>
                        <p className="text-neutral-400 font-medium">{m.email} • {m.phone}</p>
                        <p className="text-[#CCFF00] text-[11px] font-bold uppercase mt-0.5">
                          Plan: {m.membershipPlanName || 'No Active Plan'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <select
                        value={m.membershipStatus}
                        onChange={(e) => updateMemberStatus(m.id, e.target.value as any)}
                        className="bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-white font-bold uppercase focus:border-[#CCFF00]"
                      >
                        <option value="active">Active Access</option>
                        <option value="inactive">Inactive</option>
                        <option value="expired">Expired</option>
                      </select>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 6. BOOKINGS MANAGEMENT */}
          {activeSection === 'bookings' && (
            <div className="space-y-6">
              <div>
                <h4 className="font-heading text-2xl font-black uppercase text-white">
                  Class & Trainer Reservations ({bookings.length})
                </h4>
                <p className="text-xs text-neutral-400 font-medium">Live roster of booked studio spots and 1-on-1 coaching bays.</p>
              </div>

              <div className="space-y-3">
                {bookings.map((b) => (
                  <div
                    key={b.id}
                    className="p-4 rounded-2xl bg-black border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                          b.type === 'class' ? 'bg-[#CCFF00]/20 text-[#CCFF00] border border-[#CCFF00]/40' : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                        }`}>
                          {b.type}
                        </span>
                        <h5 className="font-heading text-lg font-black uppercase text-white">{b.itemTitle}</h5>
                      </div>
                      <p className="text-neutral-400 font-medium">
                        Member: <strong className="text-white">{b.userName}</strong> ({b.userEmail})
                      </p>
                      <p className="text-neutral-300">
                        Date: {b.day ? `${b.day} (${b.date})` : b.date} at {b.time} • Room: {b.room || 'General'}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-auto">
                      <span className={`px-3 py-1 rounded-full text-xs font-black uppercase ${
                        b.status === 'confirmed' ? 'bg-emerald-950 text-emerald-300 border border-emerald-700' : 'bg-red-950 text-red-300 border border-red-800'
                      }`}>
                        {b.status}
                      </span>
                      {b.status === 'confirmed' && (
                        <button
                          onClick={() => cancelBooking(b.id)}
                          className="p-2 rounded-lg bg-neutral-900 hover:bg-red-950 text-neutral-400 hover:text-red-400 cursor-pointer transition-colors"
                          title="Cancel on behalf of member"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 7. CONTACT MESSAGES */}
          {activeSection === 'messages' && (
            <div className="space-y-6">
              <div>
                <h4 className="font-heading text-2xl font-black uppercase text-white">
                  Contact Inquiries Inbox ({messages.length})
                </h4>
                <p className="text-xs text-neutral-400 font-medium">Direct questions and tour requests submitted through the contact form.</p>
              </div>

              <div className="space-y-3">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className="p-5 rounded-2xl bg-black border border-neutral-800 space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-900 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className="font-bold text-white text-sm">{msg.name}</h5>
                          <span className="text-xs text-neutral-400 font-mono">&lt;{msg.email}&gt;</span>
                        </div>
                        <p className="text-xs text-[#CCFF00] font-bold uppercase mt-0.5">Subject: {msg.subject}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-neutral-500 font-mono">{msg.date}</span>
                        <select
                          value={msg.status}
                          onChange={(e) => markMessageStatus(msg.id, e.target.value as any)}
                          className="bg-neutral-900 border border-neutral-800 rounded-lg px-2.5 py-1 text-xs text-white font-bold"
                        >
                          <option value="unread">Unread</option>
                          <option value="read">Read</option>
                          <option value="replied">Replied</option>
                        </select>
                        <button
                          onClick={() => deleteMessage(msg.id)}
                          className="p-1.5 text-neutral-500 hover:text-red-400 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <p className="text-xs text-neutral-300 leading-relaxed bg-neutral-900/60 p-3 rounded-xl border border-neutral-900">
                      "{msg.message}"
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 8. FACILITY & GYM INFO */}
          {activeSection === 'facility' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                updateGymInfo(facilityForm);
              }}
              className="space-y-6 max-w-2xl"
            >
              <div>
                <h4 className="font-heading text-2xl font-black uppercase text-white">
                  Gym Profile & Facility Hours
                </h4>
                <p className="text-xs text-neutral-400 font-medium">Update address, opening times, phone, and embed links across the site.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-neutral-300 uppercase">Gym Name</label>
                  <input
                    value={facilityForm.name}
                    onChange={(e) => setFacilityForm({ ...facilityForm, name: e.target.value })}
                    className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2 text-xs text-white focus:border-[#CCFF00]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-neutral-300 uppercase">Direct Phone</label>
                  <input
                    value={facilityForm.phone}
                    onChange={(e) => setFacilityForm({ ...facilityForm, phone: e.target.value })}
                    className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2 text-xs text-white focus:border-[#CCFF00]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-300 uppercase">Headline / Tagline</label>
                <input
                  value={facilityForm.tagline}
                  onChange={(e) => setFacilityForm({ ...facilityForm, tagline: e.target.value })}
                  className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2 text-xs text-white focus:border-[#CCFF00]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-neutral-300 uppercase">Street Address</label>
                  <input
                    value={facilityForm.address}
                    onChange={(e) => setFacilityForm({ ...facilityForm, address: e.target.value })}
                    className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2 text-xs text-white focus:border-[#CCFF00]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-neutral-300 uppercase">City, State Zip</label>
                  <input
                    value={facilityForm.cityStateZip}
                    onChange={(e) => setFacilityForm({ ...facilityForm, cityStateZip: e.target.value })}
                    className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2 text-xs text-white focus:border-[#CCFF00]"
                  />
                </div>
              </div>

              <div className="space-y-3 pt-2 border-t border-neutral-800">
                <h5 className="text-xs font-black text-[#CCFF00] uppercase tracking-wider">Facility Hours</h5>
                <div className="space-y-2">
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5 font-medium">Monday - Friday</label>
                    <input
                      value={facilityForm.hoursWeekday}
                      onChange={(e) => setFacilityForm({ ...facilityForm, hoursWeekday: e.target.value })}
                      className="w-full bg-black border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:border-[#CCFF00]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5 font-medium">Saturday</label>
                    <input
                      value={facilityForm.hoursSaturday}
                      onChange={(e) => setFacilityForm({ ...facilityForm, hoursSaturday: e.target.value })}
                      className="w-full bg-black border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:border-[#CCFF00]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5 font-medium">Sunday</label>
                    <input
                      value={facilityForm.hoursSunday}
                      onChange={(e) => setFacilityForm({ ...facilityForm, hoursSunday: e.target.value })}
                      className="w-full bg-black border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:border-[#CCFF00]"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="py-3 px-6 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-lg font-black uppercase tracking-wider transition-colors shadow-lg shadow-[#CCFF00]/20 cursor-pointer"
              >
                Save Facility Details
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
