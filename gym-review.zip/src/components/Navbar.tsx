import React, { useState, useEffect } from 'react';
import { useGym } from '../context/GymContext';
import {
  Menu,
  X,
  User,
  ShieldCheck,
  Calendar,
  LogOut,
  Sparkles,
  ChevronRight,
  Star
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentUser,
    logout,
    setIsAuthModalOpen,
    setIsDashboardOpen,
    setIsAdminDashboardOpen,
    setSelectedPlanForCheckout,
    membershipPlans
  } = useGym();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
      const sections = ['home', 'about', 'programs', 'trainers', 'membership', 'schedule', 'calculator', 'gallery', 'contact'];
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 140 && rect.bottom >= 140) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#home', id: 'home' },
    { label: 'About', href: '#about', id: 'about' },
    { label: 'Programs', href: '#programs', id: 'programs' },
    { label: 'Trainers', href: '#trainers', id: 'trainers' },
    { label: 'Membership', href: '#membership', id: 'membership' },
    { label: 'Schedule', href: '#schedule', id: 'schedule' },
    { label: 'Calculator', href: '#calculator', id: 'calculator' },
    { label: 'Gallery', href: '#gallery', id: 'gallery' },
    { label: 'Contact', href: '#contact', id: 'contact' },
  ];

  const handleJoinClick = () => {
    const defaultPlan = membershipPlans.find((p) => p.popular) || membershipPlans[0];
    setSelectedPlanForCheckout(defaultPlan);
    setMobileMenuOpen(false);
  };

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#0A0A0A]/95 backdrop-blur-xl border-b border-neutral-800 shadow-2xl py-3'
          : 'bg-gradient-to-b from-[#0A0A0A]/95 via-[#0A0A0A]/50 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <a
          id="nav-logo"
          href="#home"
          className="flex items-center gap-2.5 group cursor-pointer focus:outline-none"
        >
          <div className="w-10 h-10 rounded-xl bg-[#CCFF00] flex items-center justify-center shadow-lg shadow-[#CCFF00]/20 group-hover:scale-105 transition-transform duration-200">
            <Star className="w-6 h-6 text-black fill-black" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-heading text-2xl sm:text-3xl font-black tracking-tight text-white">
                STAR
              </span>
              <span className="font-heading text-2xl sm:text-3xl font-black tracking-tight text-[#CCFF00]">
                FITNESS
              </span>
            </div>
            <span className="text-[9px] uppercase font-black tracking-[0.28em] text-neutral-400 -mt-1">
              STUDIO • ELITE GYM
            </span>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <nav id="nav-links-desktop" className="hidden xl:flex items-center gap-1 bg-[#141414] p-1.5 rounded-full border border-neutral-800 backdrop-blur-md">
          {navLinks.map((link) => (
            <a
              key={link.id}
              id={`nav-link-${link.id}`}
              href={link.href}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-200 ${
                activeSection === link.id
                  ? 'bg-[#CCFF00] text-black font-black shadow-md shadow-[#CCFF00]/20'
                  : 'text-neutral-300 hover:text-white hover:bg-neutral-800'
              }`}
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Action Controls & User Switch */}
        <div className="hidden md:flex items-center gap-3">
          {currentUser ? (
            <div className="flex items-center gap-2">
              {currentUser.role === 'admin' ? (
                <button
                  id="nav-admin-panel-btn"
                  onClick={() => setIsAdminDashboardOpen(true)}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-red-950/80 border border-red-700/60 text-red-300 hover:bg-red-900/80 hover:text-white text-xs font-bold uppercase tracking-wider transition-all shadow-md cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 text-red-400" />
                  <span>Admin Panel</span>
                </button>
              ) : (
                <button
                  id="nav-member-dashboard-btn"
                  onClick={() => setIsDashboardOpen(true)}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#141414] border border-neutral-700 hover:border-[#CCFF00]/60 text-neutral-200 hover:text-white text-xs font-bold uppercase tracking-wider transition-all cursor-pointer"
                >
                  <Calendar className="w-4 h-4 text-[#CCFF00]" />
                  <span>My Portal</span>
                  {currentUser.membershipStatus === 'active' && (
                    <span className="w-2 h-2 rounded-full bg-[#CCFF00] animate-pulse"></span>
                  )}
                </button>
              )}

              {/* User Profile avatar trigger */}
              <div className="flex items-center gap-2 pl-2 border-l border-neutral-800">
                <button
                  id="nav-user-profile-btn"
                  onClick={() => {
                    if (currentUser.role === 'admin') {
                      setIsAdminDashboardOpen(true);
                    } else {
                      setIsDashboardOpen(true);
                    }
                  }}
                  className="flex items-center gap-2 text-left group cursor-pointer"
                  title="View Profile"
                >
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-8 h-8 rounded-full object-cover border border-[#CCFF00]/60 group-hover:border-[#CCFF00] transition-colors"
                  />
                  <div className="hidden lg:block">
                    <p className="text-xs font-bold text-neutral-200 group-hover:text-[#CCFF00] transition-colors truncate max-w-[100px]">
                      {currentUser.name.split(' ')[0]}
                    </p>
                    <p className="text-[10px] text-neutral-400 capitalize font-medium">
                      {currentUser.role}
                    </p>
                  </div>
                </button>
                <button
                  id="nav-logout-btn"
                  onClick={logout}
                  className="p-2 rounded-lg text-neutral-400 hover:text-red-400 hover:bg-neutral-900 transition-colors cursor-pointer"
                  title="Sign Out"
                  aria-label="Sign out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            <button
              id="nav-login-btn"
              onClick={() => setIsAuthModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-neutral-300 hover:text-white text-xs font-bold uppercase tracking-wider hover:bg-[#141414] transition-colors cursor-pointer"
            >
              <User className="w-4 h-4 text-neutral-400" />
              <span>Login</span>
            </button>
          )}

          {/* Join Now Primary CTA */}
          <button
            id="nav-join-now-btn"
            onClick={handleJoinClick}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-lg font-black uppercase tracking-wider shadow-lg shadow-[#CCFF00]/25 hover:shadow-[#CCFF00]/40 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-black fill-black" />
            <span>Join Now</span>
          </button>
        </div>

        {/* Mobile Menu Hamburger */}
        <div className="flex items-center gap-2 md:hidden">
          <button
            id="nav-mobile-join-btn"
            onClick={handleJoinClick}
            className="px-3 py-1.5 rounded-lg bg-[#CCFF00] text-black font-heading text-sm font-black uppercase tracking-wider cursor-pointer"
          >
            Join
          </button>
          <button
            id="nav-mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg bg-[#141414] text-neutral-300 hover:text-white border border-neutral-800 cursor-pointer"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="nav-mobile-drawer"
          className="md:hidden bg-[#0A0A0A]/98 border-b border-neutral-800 px-5 pt-4 pb-8 space-y-4 max-h-[85vh] overflow-y-auto"
        >
          {/* User state preview on mobile */}
          {currentUser ? (
            <div className="p-3.5 rounded-xl bg-[#141414] border border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-10 h-10 rounded-full object-cover border border-[#CCFF00]"
                />
                <div>
                  <p className="text-sm font-bold text-white">{currentUser.name}</p>
                  <p className="text-xs text-[#CCFF00] capitalize font-semibold">
                    {currentUser.membershipPlanName || `${currentUser.role} account`}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {currentUser.role === 'admin' ? (
                  <button
                    id="mobile-nav-admin-btn"
                    onClick={() => {
                      setIsAdminDashboardOpen(true);
                      setMobileMenuOpen(false);
                    }}
                    className="p-2 rounded-lg bg-red-950 text-red-300 border border-red-800 text-xs font-bold cursor-pointer"
                  >
                    Admin
                  </button>
                ) : (
                  <button
                    id="mobile-nav-portal-btn"
                    onClick={() => {
                      setIsDashboardOpen(true);
                      setMobileMenuOpen(false);
                    }}
                    className="p-2 rounded-lg bg-[#CCFF00]/20 text-[#CCFF00] border border-[#CCFF00]/30 text-xs font-bold cursor-pointer"
                  >
                    Portal
                  </button>
                )}
                <button
                  id="mobile-nav-logout-btn"
                  onClick={logout}
                  className="p-2 text-neutral-400 hover:text-red-400 cursor-pointer"
                  aria-label="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <button
                id="mobile-nav-login-btn"
                onClick={() => {
                  setIsAuthModalOpen(true);
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 rounded-xl bg-[#141414] border border-neutral-700 text-white font-bold text-xs uppercase cursor-pointer"
              >
                Sign In
              </button>
              <button
                id="mobile-nav-demo-btn"
                onClick={() => {
                  setIsAuthModalOpen(true);
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 rounded-xl bg-[#CCFF00] text-black font-black text-xs uppercase cursor-pointer"
              >
                Demo Accounts
              </button>
            </div>
          )}

          {/* Links list */}
          <div className="space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.id}
                id={`mobile-nav-link-${link.id}`}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center justify-between px-4 py-3 rounded-xl text-sm font-semibold uppercase tracking-wider transition-colors ${
                  activeSection === link.id
                    ? 'bg-[#CCFF00]/15 text-[#CCFF00] border border-[#CCFF00]/30 font-bold'
                    : 'text-neutral-300 hover:bg-neutral-900 hover:text-white'
                }`}
              >
                <span>{link.label}</span>
                <ChevronRight className="w-4 h-4 text-neutral-500" />
              </a>
            ))}
          </div>

          <div className="pt-2 border-t border-neutral-800">
            <button
              id="mobile-nav-join-primary-btn"
              onClick={handleJoinClick}
              className="w-full py-3 rounded-xl bg-[#CCFF00] text-black font-heading text-xl font-black uppercase tracking-wider shadow-lg shadow-[#CCFF00]/20 cursor-pointer"
            >
              Get Your All-Access Pass
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
