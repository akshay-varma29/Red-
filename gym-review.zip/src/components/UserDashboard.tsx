import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import {
  X,
  User,
  Calendar,
  CreditCard,
  QrCode,
  Star,
  CheckCircle2,
  Clock,
  MapPin,
  Trash2,
  Activity,
  Award,
  Crown,
  ChevronRight,
  Zap,
  Sparkles
} from 'lucide-react';

export const UserDashboard: React.FC = () => {
  const {
    currentUser,
    isDashboardOpen,
    setIsDashboardOpen,
    bookings,
    cancelBooking,
    cancelMembership,
    membershipPlans,
    setSelectedPlanForCheckout,
    updateUserProfile,
    logout
  } = useGym();

  const [activeTab, setActiveTab] = useState<'overview' | 'classes' | 'profile'>('overview');

  // Edit Profile Local State
  const [editName, setEditName] = useState(currentUser?.name || '');
  const [editPhone, setEditPhone] = useState(currentUser?.phone || '');
  const [editGoal, setEditGoal] = useState(currentUser?.fitnessGoal || '');
  const [editHeight, setEditHeight] = useState(currentUser?.heightCm || 175);
  const [editWeight, setEditWeight] = useState(currentUser?.weightKg || 75);

  if (!isDashboardOpen || !currentUser) return null;

  const userBookings = bookings.filter(
    (b) => b.userId === currentUser.id && b.status === 'confirmed'
  );

  const currentPlan = membershipPlans.find((p) => p.id === currentUser.membershipPlanId);

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      name: editName,
      phone: editPhone,
      fitnessGoal: editGoal,
      heightCm: Number(editHeight),
      weightKg: Number(editWeight),
      calculatedBmi: +(Number(editWeight) / ((Number(editHeight) / 100) * (Number(editHeight) / 100))).toFixed(1)
    });
  };

  return (
    <div
      id="user-dashboard-overlay"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
    >
      <div className="bg-[#141414] border border-neutral-800 rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col relative shadow-2xl overflow-hidden my-6">
        {/* Modal Top Bar */}
        <div className="p-6 border-b border-neutral-800 flex items-center justify-between bg-black">
          <div className="flex items-center gap-4">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-[#CCFF00] shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-heading text-2xl sm:text-3xl font-black uppercase text-white">
                  {currentUser.name}
                </h3>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                  currentUser.membershipStatus === 'active'
                    ? 'bg-emerald-950 text-[#CCFF00] border border-[#CCFF00]/50'
                    : 'bg-red-950 text-red-300 border border-red-700'
                }`}>
                  {currentUser.membershipStatus}
                </span>
              </div>
              <p className="text-xs text-neutral-400 font-medium">
                {currentUser.membershipPlanName || 'No Active Membership'} • Member since {currentUser.memberSince}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="user-dashboard-close-btn"
              onClick={() => setIsDashboardOpen(false)}
              className="p-2.5 rounded-xl text-neutral-400 hover:text-white bg-[#141414] border border-neutral-800 transition-colors cursor-pointer"
              aria-label="Close Dashboard"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-neutral-800 bg-black px-6 gap-4">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 text-xs font-black uppercase tracking-wider border-b-2 transition-colors cursor-pointer ${
              activeTab === 'overview'
                ? 'border-[#CCFF00] text-[#CCFF00]'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            Digital Pass & Membership
          </button>
          <button
            onClick={() => setActiveTab('classes')}
            className={`py-3 text-xs font-black uppercase tracking-wider border-b-2 transition-colors cursor-pointer flex items-center gap-2 ${
              activeTab === 'classes'
                ? 'border-[#CCFF00] text-[#CCFF00]'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <span>My Bookings</span>
            <span className="px-2 py-0.5 rounded-full bg-[#141414] border border-neutral-700 text-[10px] font-bold text-white">
              {userBookings.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`py-3 text-xs font-black uppercase tracking-wider border-b-2 transition-colors cursor-pointer ${
              activeTab === 'profile'
                ? 'border-[#CCFF00] text-[#CCFF00]'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            Personal Metrics & Goals
          </button>
        </div>

        {/* Tab Content Container */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: OVERVIEW & KEYCARD */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Digital Pass & QR Keycard Card */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
                {/* Visual Membership Pass */}
                <div className="md:col-span-7 rounded-3xl p-6 bg-black border border-[#CCFF00]/40 shadow-2xl relative overflow-hidden flex flex-col justify-between space-y-6">
                  {/* Watermark Logo */}
                  <div className="absolute right-4 bottom-4 opacity-5 pointer-events-none">
                    <Star className="w-48 h-48 text-[#CCFF00]" />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-[#CCFF00] flex items-center justify-center text-black font-black">
                        <Star className="w-5 h-5 fill-black" />
                      </div>
                      <span className="font-heading text-xl font-black tracking-wider text-white">
                        STAR KEYCARD PASS
                      </span>
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-[#141414] text-[#CCFF00] text-[10px] font-black uppercase tracking-wider border border-[#CCFF00]/40">
                      24/7 ALL-ACCESS
                    </span>
                  </div>

                  {/* QR & Barcode Section */}
                  <div className="flex items-center gap-6 p-4 rounded-2xl bg-[#141414] border border-neutral-800 backdrop-blur-md">
                    {/* QR Code */}
                    <div className="w-20 h-20 bg-white p-2 rounded-xl shrink-0 flex items-center justify-center">
                      <QrCode className="w-16 h-16 text-black" />
                    </div>
                    <div className="space-y-1 min-w-0">
                      <p className="text-[10px] font-black text-neutral-400 uppercase tracking-widest">
                        Digital Member Token
                      </p>
                      <p className="font-mono text-base font-black text-[#CCFF00] tracking-wider truncate">
                        {currentUser.qrCode}
                      </p>
                      <p className="text-[10px] text-neutral-400">
                        Scan at turnstile scanner or locker terminals
                      </p>
                    </div>
                  </div>

                  {/* Card Bottom Meta */}
                  <div className="flex items-center justify-between text-xs text-neutral-300 pt-2 border-t border-neutral-800">
                    <div>
                      <span className="text-[10px] text-neutral-500 uppercase block font-bold">Tier</span>
                      <span className="font-heading text-lg font-black text-white uppercase">{currentUser.membershipPlanName || 'Standard Trial'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-500 uppercase block font-bold">Valid Thru</span>
                      <span className="font-mono font-bold text-neutral-200">{currentUser.membershipRenewsAt || 'Active Session'}</span>
                    </div>
                  </div>
                </div>

                {/* Membership Actions & Benefits */}
                <div className="md:col-span-5 rounded-3xl p-6 bg-black border border-neutral-800 flex flex-col justify-between space-y-4">
                  <div>
                    <h4 className="font-heading text-xl font-black uppercase text-white mb-2">
                      Plan Privileges
                    </h4>
                    {currentPlan ? (
                      <div className="space-y-2 text-xs">
                        <div className="p-2.5 rounded-xl bg-[#141414] border border-neutral-800 space-y-0.5">
                          <span className="text-[10px] font-black text-[#CCFF00] uppercase">Training Access</span>
                          <p className="text-neutral-300 font-medium">{currentPlan.trainingAccess}</p>
                        </div>
                        <div className="p-2.5 rounded-xl bg-[#141414] border border-neutral-800 space-y-0.5">
                          <span className="text-[10px] font-black text-[#CCFF00] uppercase">Coaching Included</span>
                          <p className="text-neutral-300 font-medium">{currentPlan.personalTrainingSessions}</p>
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-neutral-400 font-medium">
                        You do not currently have an active membership tier. Select a pass to unlock 24/7 access, recovery lounge, and unlimited studio classes.
                      </p>
                    )}
                  </div>

                  <div className="space-y-2 pt-2 border-t border-neutral-800">
                    <button
                      onClick={() => {
                        const proPlan = membershipPlans.find((p) => p.name === 'Pro') || membershipPlans[0];
                        setSelectedPlanForCheckout(proPlan);
                      }}
                      className="w-full py-3 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-lg font-black uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-[#CCFF00]/20"
                    >
                      <Crown className="w-4 h-4" />
                      <span>Change / Upgrade Plan</span>
                    </button>
                    {currentUser.membershipStatus === 'active' && (
                      <button
                        onClick={cancelMembership}
                        className="w-full py-2 text-[11px] text-neutral-500 hover:text-red-400 font-bold uppercase tracking-wider transition-colors cursor-pointer"
                      >
                        Cancel Auto-Renew
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Quick Diagnostic Metrics Snapshot */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-black border border-neutral-800 space-y-1">
                  <span className="text-[10px] text-neutral-400 uppercase font-black tracking-wider">Body Mass Index</span>
                  <p className="font-heading text-3xl font-black text-[#CCFF00]">
                    {currentUser.calculatedBmi || '25.4'}
                  </p>
                  <p className="text-[10px] text-neutral-400 font-bold uppercase truncate">{currentUser.bmiCategory || 'Optimal Athletic'}</p>
                </div>
                <div className="p-4 rounded-2xl bg-black border border-neutral-800 space-y-1">
                  <span className="text-[10px] text-neutral-400 uppercase font-black tracking-wider">Current Weight</span>
                  <p className="font-heading text-3xl font-black text-white">
                    {currentUser.weightKg || 84} <span className="text-xs text-neutral-400 font-sans">kg</span>
                  </p>
                  <p className="text-[10px] text-neutral-400 font-mono">{Math.round((currentUser.weightKg || 84) * 2.20462)} lbs</p>
                </div>
                <div className="p-4 rounded-2xl bg-black border border-neutral-800 space-y-1">
                  <span className="text-[10px] text-neutral-400 uppercase font-black tracking-wider">Height</span>
                  <p className="font-heading text-3xl font-black text-white">
                    {currentUser.heightCm || 182} <span className="text-xs text-neutral-400 font-sans">cm</span>
                  </p>
                  <p className="text-[10px] text-neutral-400 font-mono">5' 11"</p>
                </div>
                <div className="p-4 rounded-2xl bg-black border border-neutral-800 space-y-1">
                  <span className="text-[10px] text-neutral-400 uppercase font-black tracking-wider">Active Reservations</span>
                  <p className="font-heading text-3xl font-black text-[#CCFF00]">
                    {userBookings.length}
                  </p>
                  <p className="text-[10px] text-neutral-400 font-bold uppercase">Confirmed Spots</p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: MY BOOKINGS */}
          {activeTab === 'classes' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-heading text-xl sm:text-2xl font-black uppercase text-white">
                  Upcoming Reservations & 1-on-1 Sessions
                </h4>
                <a
                  href="#schedule"
                  onClick={() => setIsDashboardOpen(false)}
                  className="text-xs text-[#CCFF00] hover:underline font-black uppercase tracking-wider"
                >
                  + Book More Classes
                </a>
              </div>

              {userBookings.length === 0 ? (
                <div className="p-12 rounded-2xl bg-black border border-neutral-800 text-center space-y-3">
                  <Calendar className="w-12 h-12 text-neutral-600 mx-auto" />
                  <h4 className="font-heading text-xl font-black text-white uppercase">No upcoming reservations</h4>
                  <p className="text-xs text-neutral-400 max-w-sm mx-auto font-medium">
                    You haven't reserved any studio classes or private trainer slots yet. Browse the schedule and book your spot.
                  </p>
                  <a
                    href="#schedule"
                    onClick={() => setIsDashboardOpen(false)}
                    className="inline-block px-5 py-2.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-black text-xs uppercase tracking-wider"
                  >
                    View Timetable
                  </a>
                </div>
              ) : (
                <div className="space-y-3">
                  {userBookings.map((b) => (
                    <div
                      key={b.id}
                      className="p-4 sm:p-5 rounded-2xl bg-black border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                            b.type === 'class' ? 'bg-[#CCFF00]/20 text-[#CCFF00] border border-[#CCFF00]/40' : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                          }`}>
                            {b.type === 'class' ? 'Studio Class' : '1-on-1 Coaching'}
                          </span>
                          <h5 className="font-heading text-xl sm:text-2xl font-black uppercase text-white">{b.itemTitle}</h5>
                        </div>
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-neutral-400">
                          <span className="flex items-center gap-1 font-mono">
                            <Clock className="w-3.5 h-3.5 text-[#CCFF00]" />
                            {b.day ? `${b.day} (${b.date})` : b.date} at {b.time}
                          </span>
                          {b.trainerName && (
                            <span className="flex items-center gap-1 text-neutral-300 font-bold">
                              <Award className="w-3.5 h-3.5 text-[#CCFF00]" />
                              Coach {b.trainerName}
                            </span>
                          )}
                          {b.room && (
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5 text-neutral-500" />
                              {b.room}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-auto">
                        <span className="px-3 py-1 rounded-full bg-emerald-950 text-[#CCFF00] border border-[#CCFF00]/40 text-xs font-black uppercase">
                          Confirmed
                        </span>
                        <button
                          onClick={() => cancelBooking(b.id)}
                          className="p-2 rounded-xl text-neutral-400 hover:text-red-400 hover:bg-[#141414] border border-neutral-800 transition-colors cursor-pointer"
                          title="Cancel Reservation"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PROFILE & METRICS */}
          {activeTab === 'profile' && (
            <form onSubmit={handleProfileSave} className="space-y-4 max-w-xl">
              <h4 className="font-heading text-xl sm:text-2xl font-black uppercase text-white mb-2">
                Personal Information & Fitness Target
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white focus:border-[#CCFF00] focus:outline-none font-medium"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white focus:border-[#CCFF00] focus:outline-none font-medium"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                  Primary Fitness Target & Goals
                </label>
                <input
                  type="text"
                  value={editGoal}
                  onChange={(e) => setEditGoal(e.target.value)}
                  className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white focus:border-[#CCFF00] focus:outline-none font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                    Height (cm)
                  </label>
                  <input
                    type="number"
                    value={editHeight}
                    onChange={(e) => setEditHeight(Number(e.target.value))}
                    className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white focus:border-[#CCFF00] focus:outline-none font-mono font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                    Weight (kg)
                  </label>
                  <input
                    type="number"
                    value={editWeight}
                    onChange={(e) => setEditWeight(Number(e.target.value))}
                    className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white focus:border-[#CCFF00] focus:outline-none font-mono font-bold"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="py-3.5 px-8 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-lg font-black uppercase tracking-wider transition-colors shadow-lg shadow-[#CCFF00]/20 cursor-pointer"
              >
                Save Changes
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
