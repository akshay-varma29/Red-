import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import { DayOfWeek } from '../types';
import {
  Calendar,
  Clock,
  MapPin,
  Flame,
  Filter,
  CheckCircle2,
  Zap
} from 'lucide-react';

export const Schedule: React.FC = () => {
  const { schedule, bookClass, currentUser, bookings } = useGym();
  const days: DayOfWeek[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const todayName = new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date()) as DayOfWeek;
  const initialDay = days.includes(todayName) ? todayName : 'Monday';

  const [activeDay, setActiveDay] = useState<DayOfWeek>(initialDay);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Strength', 'HIIT', 'Functional', 'Boxing', 'Cycling', 'Yoga', 'Cardio'];

  const filteredSchedule = schedule.filter((item) => {
    const matchesDay = item.day === activeDay;
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesDay && matchesCategory;
  });

  const getIntensityBadge = (intensity: string) => {
    switch (intensity) {
      case 'Low':
        return 'bg-blue-950/80 text-blue-300 border-blue-800';
      case 'Medium':
        return 'bg-neutral-900 text-[#CCFF00] border-[#CCFF00]/40';
      case 'High':
        return 'bg-[#CCFF00] text-black border-[#CCFF00] font-black';
      case 'Extreme':
        return 'bg-red-950/80 text-red-300 border-red-800 animate-pulse';
      default:
        return 'bg-neutral-800 text-neutral-300 border-neutral-700';
    }
  };

  return (
    <section id="schedule" className="py-24 bg-[#0E0E0E] border-t border-neutral-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141414] border border-[#CCFF00]/40">
              <Calendar className="w-4 h-4 text-[#CCFF00]" />
              <span className="text-xs font-black uppercase tracking-widest text-[#CCFF00]">
                WEEKLY CLASS TIMETABLE
              </span>
            </div>
            <h2 className="font-heading text-4xl sm:text-5xl lg:text-7xl font-black uppercase text-white tracking-tight leading-none">
              RESERVE YOUR SPOT IN <span className="text-[#CCFF00]">SIGNATURE CLASSES</span>
            </h2>
            <p className="text-neutral-300 text-sm sm:text-base">
              Live capacity monitoring. Reserve your spot up to 7 days in advance.
              Arrive 10 minutes early for heart rate monitor sync and mobility prep.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-black text-white bg-[#141414] p-3.5 rounded-2xl border border-neutral-800">
            <Flame className="w-4 h-4 text-[#CCFF00] fill-[#CCFF00]" />
            <span className="uppercase">Fast-Filling Sessions • Live Seat Counts</span>
          </div>
        </div>

        {/* Day Selector Tabs */}
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 mb-6">
          {days.map((day) => {
            const isToday = day === todayName;
            const isActive = activeDay === day;
            const countForDay = schedule.filter((s) => s.day === day).length;

            return (
              <button
                key={day}
                id={`schedule-day-${day.toLowerCase()}`}
                onClick={() => setActiveDay(day)}
                className={`py-3.5 px-2 rounded-2xl border text-center transition-all duration-200 cursor-pointer flex flex-col items-center justify-center gap-1 ${
                  isActive
                    ? 'bg-[#CCFF00] border-[#CCFF00] text-black font-black shadow-lg shadow-[#CCFF00]/20 ring-1 ring-[#CCFF00]'
                    : 'bg-[#141414] border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                }`}
              >
                <span className="text-[11px] font-black uppercase tracking-wider">
                  {day.slice(0, 3)}
                </span>
                <span className={`text-[10px] font-bold ${isActive ? 'text-black font-black' : 'text-neutral-400'}`}>
                  {countForDay} Classes
                </span>
                {isToday && (
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      isActive ? 'bg-black' : 'bg-[#CCFF00]'
                    }`}
                  />
                )}
              </button>
            );
          })}
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8">
          <span className="text-xs font-black text-neutral-400 uppercase tracking-wider pl-1 pr-2 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-[#CCFF00]" /> Category:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              id={`schedule-cat-${cat.toLowerCase()}`}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#CCFF00] text-black'
                  : 'bg-[#141414] text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Schedule List / Grid */}
        <div className="space-y-3">
          {filteredSchedule.map((item) => {
            const seatsRemaining = item.maxSeats - item.bookedSeats;
            const isFull = seatsRemaining <= 0;
            const isAlmostFull = seatsRemaining > 0 && seatsRemaining <= 4;
            const isUserBooked = bookings.some(
              (b) =>
                b.userId === currentUser?.id &&
                b.itemId === item.id &&
                b.status === 'confirmed'
            );

            return (
              <div
                key={item.id}
                id={`schedule-item-${item.id}`}
                className="p-5 sm:p-6 rounded-2xl bg-[#141414] border border-neutral-800 hover:border-[#CCFF00]/40 transition-all duration-200 flex flex-col lg:flex-row lg:items-center justify-between gap-6 shadow-md"
              >
                {/* Time & Title Info */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6 flex-1">
                  {/* Time Badge */}
                  <div className="w-32 shrink-0 flex flex-col justify-center p-3 rounded-xl bg-black border border-neutral-800 text-center">
                    <div className="flex items-center justify-center gap-1.5 text-[#CCFF00] font-mono font-bold text-sm sm:text-base">
                      <Clock className="w-4 h-4 text-[#CCFF00]" />
                      <span>{item.startTime}</span>
                    </div>
                    <span className="text-[10px] text-neutral-400 font-medium mt-0.5">
                      Until {item.endTime}
                    </span>
                  </div>

                  {/* Class Meta */}
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-heading text-2xl font-black uppercase text-white tracking-tight">
                        {item.title}
                      </h3>
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${getIntensityBadge(
                          item.intensity
                        )}`}
                      >
                        {item.intensity} Intensity
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-[#1F1F1F] text-neutral-300 text-[10px] font-bold border border-neutral-800 uppercase">
                        {item.category}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-neutral-400 font-medium">
                      <span className="flex items-center gap-1.5 text-neutral-200 font-bold uppercase">
                        <img
                          src={item.trainerImage}
                          alt={item.trainerName}
                          className="w-4 h-4 rounded-full object-cover border border-[#CCFF00]"
                        />
                        Coach {item.trainerName}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-[#CCFF00]" />
                        {item.room}
                      </span>
                      <span className="flex items-center gap-1 text-[#CCFF00] font-bold">
                        <Flame className="w-3.5 h-3.5 fill-[#CCFF00]" />
                        Burn {item.calorieBurn}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Capacity & Booking Action */}
                <div className="flex items-center justify-between sm:justify-end gap-6 border-t lg:border-t-0 pt-4 lg:pt-0 border-neutral-800">
                  {/* Live Seats Progress Bar */}
                  <div className="w-36 text-right space-y-1">
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-neutral-400 text-[11px] uppercase">Capacity:</span>
                      <span
                        className={`font-mono text-xs ${
                          isFull
                            ? 'text-red-400'
                            : isAlmostFull
                            ? 'text-[#CCFF00]'
                            : 'text-[#CCFF00]'
                        }`}
                      >
                        {isFull ? 'FULL' : `${seatsRemaining} left`}
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-black overflow-hidden border border-neutral-800">
                      <div
                        className={`h-full transition-all duration-500 ${
                          isFull
                            ? 'bg-red-500'
                            : isAlmostFull
                            ? 'bg-[#CCFF00]'
                            : 'bg-[#CCFF00]'
                        }`}
                        style={{
                          width: `${(item.bookedSeats / item.maxSeats) * 100}%`
                        }}
                      />
                    </div>
                    <span className="text-[10px] text-neutral-400 font-medium">
                      {item.bookedSeats} / {item.maxSeats} spots filled
                    </span>
                  </div>

                  {/* Book Button */}
                  <div>
                    {isUserBooked ? (
                      <button
                        disabled
                        className="px-5 py-3 rounded-xl bg-black border border-[#CCFF00]/60 text-[#CCFF00] font-heading text-base font-black uppercase tracking-wider flex items-center gap-2 cursor-default"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Reserved</span>
                      </button>
                    ) : isFull ? (
                      <button
                        disabled
                        className="px-5 py-3 rounded-xl bg-[#1F1F1F] border border-neutral-800 text-neutral-500 font-heading text-base font-black uppercase tracking-wider cursor-not-allowed"
                      >
                        Waitlist Only
                      </button>
                    ) : (
                      <button
                        id={`book-class-btn-${item.id}`}
                        onClick={() => bookClass(item.id)}
                        className="px-6 py-3 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-lg font-black uppercase tracking-wider transition-all duration-200 hover:scale-105 active:scale-95 shadow-md shadow-[#CCFF00]/20 cursor-pointer flex items-center gap-2"
                      >
                        <Zap className="w-4 h-4 fill-black" />
                        <span>Book Spot</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {filteredSchedule.length === 0 && (
            <div className="text-center py-16 bg-[#141414] rounded-3xl border border-neutral-800 space-y-3">
              <Calendar className="w-12 h-12 text-neutral-600 mx-auto" />
              <h3 className="text-lg font-bold text-white uppercase">No classes scheduled</h3>
              <p className="text-xs text-neutral-400">
                No classes match the chosen category for {activeDay}. Check other days or reset the category filter.
              </p>
              <button
                onClick={() => setSelectedCategory('All')}
                className="px-4 py-2 rounded-xl bg-[#CCFF00] text-black font-black text-xs uppercase cursor-pointer"
              >
                Reset Category
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
