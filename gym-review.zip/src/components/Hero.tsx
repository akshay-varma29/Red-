import React from 'react';
import { useGym } from '../context/GymContext';
import {
  Flame,
  Dumbbell,
  Users,
  Award,
  CalendarCheck,
  ChevronRight,
  ShieldCheck,
  Zap
} from 'lucide-react';

export const Hero: React.FC = () => {
  const { setSelectedPlanForCheckout, membershipPlans, setSelectedClassForBooking, schedule } = useGym();

  const handleJoinNow = () => {
    const recommended = membershipPlans.find((p) => p.popular) || membershipPlans[1];
    setSelectedPlanForCheckout(recommended);
  };

  const handleFreePass = () => {
    if (schedule.length > 0) {
      setSelectedClassForBooking(schedule[0]);
    } else {
      const basic = membershipPlans[0];
      setSelectedPlanForCheckout(basic);
    }
  };

  const stats = [
    { value: '2,500+', label: 'Active Members', icon: Users, accent: 'text-[#CCFF00]' },
    { value: '24+', label: 'Master Coaches', icon: Award, accent: 'text-white' },
    { value: '35+', label: 'Weekly Classes', icon: Dumbbell, accent: 'text-[#CCFF00]' },
    { value: '12+', label: 'Years Dominance', icon: ShieldCheck, accent: 'text-white' },
  ];

  return (
    <section id="home" className="relative min-h-[92vh] lg:min-h-screen flex flex-col justify-center pt-24 pb-16 overflow-hidden bg-[#0A0A0A]">
      {/* Background Image with Dark Gradient Overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2000&auto=format&fit=crop"
          alt="Star Fitness Studio Main Gym Floor"
          className="w-full h-full object-cover object-center opacity-25 scale-105 transform"
        />
        {/* Layered cinematic vignettes */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0A] via-[#0A0A0A]/90 to-[#0A0A0A]/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-[#0A0A0A]/80" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#CCFF00]/10 via-transparent to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-8 lg:py-12 flex flex-col justify-between h-full">
        {/* Main Grid Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Headline & Action Buttons */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Live energetic badge */}
            <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-[#141414] border border-[#CCFF00]/40 backdrop-blur-md">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#CCFF00] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#CCFF00]"></span>
              </span>
              <span className="text-xs font-black uppercase tracking-widest text-[#CCFF00]">
                AUSTIN'S PREMIER HIGH-PERFORMANCE GYM
              </span>
            </div>

            {/* Main Headline with Massive Bold Typography */}
            <div className="space-y-1">
              <h1 className="font-heading text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black uppercase tracking-tight text-white leading-[0.88]">
                BUILD <span className="text-[#CCFF00]">STRENGTH.</span>
                <br />
                BUILD <span className="text-white">CONFIDENCE.</span>
                <br />
                BUILD YOUR <span className="text-[#CCFF00] italic">BEST SELF.</span>
              </h1>
            </div>

            {/* Short gym description */}
            <p className="text-base sm:text-lg text-neutral-300 max-w-2xl font-normal leading-relaxed">
              Step into a high-octane atmosphere engineered for real physical transformation.
              Featuring Olympic-calibrated Eleiko barbells, Prime biomechanical machinery,
              custom turf tracks, certified master coaches, and 24/7 keycard access.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                id="hero-join-now-btn"
                onClick={handleJoinNow}
                className="px-8 py-4 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-heading text-2xl font-black uppercase tracking-wider shadow-xl shadow-[#CCFF00]/25 hover:shadow-[#CCFF00]/45 hover:scale-105 active:scale-95 transition-all cursor-pointer flex items-center gap-2"
              >
                <Zap className="w-5 h-5 fill-black" />
                <span>Join Now</span>
              </button>

              <a
                id="hero-explore-programs-btn"
                href="#programs"
                className="px-7 py-4 rounded-xl bg-[#141414] hover:bg-neutral-800 border border-neutral-700 hover:border-[#CCFF00]/50 text-white font-heading text-2xl font-black uppercase tracking-wider transition-all flex items-center gap-2"
              >
                <span>Explore Programs</span>
                <ChevronRight className="w-5 h-5 text-[#CCFF00]" />
              </a>

              <button
                id="hero-free-pass-btn"
                onClick={handleFreePass}
                className="px-5 py-4 rounded-xl text-neutral-300 hover:text-[#CCFF00] font-bold text-xs uppercase tracking-wider hover:underline transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <CalendarCheck className="w-4 h-4 text-[#CCFF00]" />
                <span>Book 1-Day Trial Pass</span>
              </button>
            </div>

            {/* Quick feature pill highlights */}
            <div className="flex flex-wrap items-center gap-3 pt-3 text-xs font-bold text-neutral-300">
              <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#141414] border border-neutral-800">
                <span className="w-2 h-2 rounded-full bg-[#CCFF00]"></span> 24/7 Keycard Access
              </span>
              <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#141414] border border-neutral-800">
                <span className="w-2 h-2 rounded-full bg-[#CCFF00]"></span> Infrared Sauna & Cryo
              </span>
              <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#141414] border border-neutral-800">
                <span className="w-2 h-2 rounded-full bg-[#CCFF00]"></span> InBody 770 Scans
              </span>
              <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#141414] border border-neutral-800">
                <span className="w-2 h-2 rounded-full bg-[#CCFF00]"></span> No Lock-In Contracts
              </span>
            </div>
          </div>

          {/* Right Column: Hero Visual Card with Dynamic Gym Highlight */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-3xl overflow-hidden border border-neutral-800 bg-[#141414] shadow-2xl p-2.5 backdrop-blur-md group">
              <div className="relative h-[380px] sm:h-[420px] rounded-2xl overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=1000&auto=format&fit=crop"
                  alt="Athletic conditioning at Star Fitness Studio"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/30 to-transparent" />

                {/* Floating Top Pill */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                  <div className="px-3 py-1.5 rounded-full bg-black/85 backdrop-blur-md border border-neutral-700 flex items-center gap-2">
                    <Flame className="w-4 h-4 text-[#CCFF00] fill-[#CCFF00]" />
                    <span className="text-xs font-black text-white uppercase tracking-wider">High-Energy Zone</span>
                  </div>
                  <div className="px-3 py-1.5 rounded-full bg-red-950/90 border border-red-700 text-red-300 text-xs font-black uppercase tracking-wider animate-pulse">
                    Live Floor Active
                  </div>
                </div>

                {/* Floating Bottom Info Box */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-black/90 backdrop-blur-md border border-neutral-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-black text-[#CCFF00] uppercase tracking-widest">Featured Combine</p>
                      <h4 className="text-base font-black uppercase text-white">Full-Body Athletic Combine</h4>
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-[#1F1F1F] text-[#CCFF00] text-xs font-black font-heading uppercase">
                      Burn ~750 kcal
                    </span>
                  </div>
                  <p className="text-xs text-neutral-300">
                    Lead by Master Coach Marcus Vance • Turf Sprints, Barbell Cleans & AirBikes
                  </p>
                </div>
              </div>

              {/* Decorative Corner Accents */}
              <div className="absolute -top-1 -right-1 w-8 h-8 border-t-2 border-r-2 border-[#CCFF00] rounded-tr-lg pointer-events-none"></div>
              <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-2 border-l-2 border-[#CCFF00] rounded-bl-lg pointer-events-none"></div>
            </div>
          </div>
        </div>

        {/* Quick Stats Banner */}
        <div className="mt-12 lg:mt-16 pt-8 border-t border-neutral-800">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
            {stats.map((stat, i) => {
              const Icon = stat.icon;
              return (
                <div
                  key={i}
                  id={`hero-stat-${i}`}
                  className="flex items-center gap-4 p-4 rounded-2xl bg-[#141414] border border-neutral-800/80 hover:border-[#CCFF00]/50 transition-all"
                >
                  <div className="w-12 h-12 rounded-xl bg-[#1F1F1F] border border-neutral-700 flex items-center justify-center shrink-0">
                    <Icon className={`w-6 h-6 ${stat.accent}`} />
                  </div>
                  <div>
                    <h3 className="font-heading text-3xl sm:text-4xl font-black text-white tracking-tight leading-none">
                      {stat.value}
                    </h3>
                    <p className="text-xs font-bold text-neutral-400 uppercase tracking-wider mt-1">
                      {stat.label}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
