import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import {
  Calculator,
  Flame,
  Scale,
  CheckCircle2,
  Heart
} from 'lucide-react';

export const BmiCalculator: React.FC = () => {
  const { currentUser, updateUserProfile, setSelectedProgramForModal, programs } = useGym();
  const [unitSystem, setUnitSystem] = useState<'metric' | 'imperial'>('metric');

  // Metric Inputs
  const [heightCm, setHeightCm] = useState<number>(175);
  const [weightKg, setWeightKg] = useState<number>(75);

  // Imperial Inputs
  const [heightFt, setHeightFt] = useState<number>(5);
  const [heightIn, setHeightIn] = useState<number>(9);
  const [weightLbs, setWeightLbs] = useState<number>(165);

  const [age, setAge] = useState<number>(28);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [activityLevel, setActivityLevel] = useState<number>(1.55);

  let totalHeightMeters = 1.75;
  let totalWeightKg = 75;

  if (unitSystem === 'metric') {
    totalHeightMeters = Math.max(0.5, heightCm / 100);
    totalWeightKg = Math.max(20, weightKg);
  } else {
    const totalInches = heightFt * 12 + heightIn;
    totalHeightMeters = Math.max(0.5, totalInches * 0.0254);
    totalWeightKg = Math.max(20, weightLbs * 0.453592);
  }

  const bmi = +(totalWeightKg / (totalHeightMeters * totalHeightMeters)).toFixed(1);

  const getBmiDetails = (score: number) => {
    if (score < 18.5) {
      return {
        category: 'Underweight',
        color: 'text-cyan-400',
        barColor: 'bg-cyan-400',
        description: 'You are below standard weight. Hypertrophy training and calorie-dense fueling recommended.',
        recommendedProg: 'Hypertrophy Muscle Building',
        gaugePercent: Math.min(100, Math.max(5, (score / 40) * 100))
      };
    } else if (score >= 18.5 && score < 25) {
      return {
        category: 'Optimal Fitness & Healthy Weight',
        color: 'text-[#CCFF00]',
        barColor: 'bg-[#CCFF00]',
        description: 'Your weight is in an ideal range. Focus on functional strength, VO2 max, and muscle density.',
        recommendedProg: 'Strength & Powerlifting',
        gaugePercent: Math.min(100, Math.max(5, (score / 40) * 100))
      };
    } else if (score >= 25 && score < 30) {
      return {
        category: 'Overweight / High Lean Mass',
        color: 'text-amber-400',
        barColor: 'bg-amber-400',
        description: 'Moderate excess mass or high athletic muscle density. Recommended: metabolic conditioning and progressive resistance.',
        recommendedProg: 'Weight Management & Shred',
        gaugePercent: Math.min(100, Math.max(5, (score / 40) * 100))
      };
    } else {
      return {
        category: 'Obesity Class Risk',
        color: 'text-red-400',
        barColor: 'bg-red-500',
        description: 'Higher health risk. A structured, low-impact conditioning and personalized nutrition program will yield rapid results.',
        recommendedProg: 'High-Octane Cardio Blast',
        gaugePercent: Math.min(100, Math.max(5, (score / 40) * 100))
      };
    }
  };

  const bmiDetails = getBmiDetails(bmi);

  let bmr = 10 * totalWeightKg + 6.25 * (totalHeightMeters * 100) - 5 * age;
  bmr = gender === 'male' ? bmr + 5 : bmr - 161;
  const tdee = Math.round(bmr * activityLevel);

  const minHealthyKg = Math.round(18.5 * totalHeightMeters * totalHeightMeters);
  const maxHealthyKg = Math.round(24.9 * totalHeightMeters * totalHeightMeters);

  const handleSaveToProfile = () => {
    if (currentUser) {
      updateUserProfile({
        heightCm: Math.round(totalHeightMeters * 100),
        weightKg: Math.round(totalWeightKg),
        calculatedBmi: bmi,
        bmiCategory: bmiDetails.category
      });
    }
  };

  return (
    <section id="calculator" className="py-24 bg-[#0A0A0A] border-t border-neutral-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141414] border border-[#CCFF00]/40">
            <Calculator className="w-4 h-4 text-[#CCFF00]" />
            <span className="text-xs font-black uppercase tracking-widest text-[#CCFF00]">
              INTERACTIVE BODY METRICS
            </span>
          </div>
          <h2 className="font-heading text-4xl sm:text-5xl lg:text-7xl font-black uppercase text-white tracking-tight leading-none">
            CALCULATE YOUR <span className="text-[#CCFF00]">BMI & DAILY CALORIES</span>
          </h2>
          <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
            Get an instant diagnostic of your Body Mass Index (BMI), estimated Total Daily Energy Expenditure (TDEE), and tailored program roadmap.
          </p>
        </div>

        {/* Main Calculator Box */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Inputs Column */}
          <div className="lg:col-span-6 bg-[#141414] border border-neutral-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            {/* Unit System Toggle */}
            <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
              <span className="text-xs font-black text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-[#CCFF00]" /> Measurement Units
              </span>
              <div className="bg-black p-1 rounded-xl border border-neutral-800 flex items-center gap-1">
                <button
                  id="bmi-unit-metric"
                  onClick={() => setUnitSystem('metric')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase transition-colors cursor-pointer ${
                    unitSystem === 'metric' ? 'bg-[#CCFF00] text-black' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Metric (cm / kg)
                </button>
                <button
                  id="bmi-unit-imperial"
                  onClick={() => setUnitSystem('imperial')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase transition-colors cursor-pointer ${
                    unitSystem === 'imperial' ? 'bg-[#CCFF00] text-black' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Imperial (ft / lbs)
                </button>
              </div>
            </div>

            {/* Gender and Age Grid */}
            <div className="grid grid-cols-2 gap-4">
              {/* Gender */}
              <div className="space-y-2">
                <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                  Gender
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setGender('male')}
                    className={`py-2.5 rounded-xl border text-xs font-black uppercase transition-colors cursor-pointer ${
                      gender === 'male'
                        ? 'bg-[#1F1F1F] text-[#CCFF00] border-[#CCFF00] ring-1 ring-[#CCFF00]'
                        : 'bg-black border-neutral-800 text-neutral-400'
                    }`}
                  >
                    Male
                  </button>
                  <button
                    onClick={() => setGender('female')}
                    className={`py-2.5 rounded-xl border text-xs font-black uppercase transition-colors cursor-pointer ${
                      gender === 'female'
                        ? 'bg-[#1F1F1F] text-[#CCFF00] border-[#CCFF00] ring-1 ring-[#CCFF00]'
                        : 'bg-black border-neutral-800 text-neutral-400'
                    }`}
                  >
                    Female
                  </button>
                </div>
              </div>

              {/* Age */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-black text-neutral-300 uppercase tracking-wider">
                    Age: <span className="text-[#CCFF00]">{age} yrs</span>
                  </label>
                </div>
                <input
                  id="bmi-age-slider"
                  type="range"
                  min="14"
                  max="85"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full h-2 bg-black rounded-lg appearance-none cursor-pointer accent-[#CCFF00]"
                />
              </div>
            </div>

            {/* Height Inputs */}
            <div className="space-y-2">
              <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                Height
              </label>
              {unitSystem === 'metric' ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Height: <strong className="text-white font-mono text-sm">{heightCm} cm</strong></span>
                    <span>({(heightCm / 30.48).toFixed(1)} ft)</span>
                  </div>
                  <input
                    id="bmi-height-cm"
                    type="range"
                    min="120"
                    max="220"
                    value={heightCm}
                    onChange={(e) => setHeightCm(Number(e.target.value))}
                    className="w-full h-2 bg-black rounded-lg appearance-none cursor-pointer accent-[#CCFF00]"
                  />
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1 uppercase font-bold">Feet</label>
                    <select
                      value={heightFt}
                      onChange={(e) => setHeightFt(Number(e.target.value))}
                      className="w-full bg-black border border-neutral-800 rounded-xl px-3 py-2 text-sm text-white font-bold"
                    >
                      {[4, 5, 6, 7].map((f) => (
                        <option key={f} value={f}>
                          {f} ft
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1 uppercase font-bold">Inches</label>
                    <select
                      value={heightIn}
                      onChange={(e) => setHeightIn(Number(e.target.value))}
                      className="w-full bg-black border border-neutral-800 rounded-xl px-3 py-2 text-sm text-white font-bold"
                    >
                      {Array.from({ length: 12 }, (_, i) => (
                        <option key={i} value={i}>
                          {i} in
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              )}
            </div>

            {/* Weight Inputs */}
            <div className="space-y-2">
              <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                Weight
              </label>
              {unitSystem === 'metric' ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Weight: <strong className="text-white font-mono text-sm">{weightKg} kg</strong></span>
                    <span>({Math.round(weightKg * 2.20462)} lbs)</span>
                  </div>
                  <input
                    id="bmi-weight-kg"
                    type="range"
                    min="35"
                    max="180"
                    value={weightKg}
                    onChange={(e) => setWeightKg(Number(e.target.value))}
                    className="w-full h-2 bg-black rounded-lg appearance-none cursor-pointer accent-[#CCFF00]"
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Weight: <strong className="text-white font-mono text-sm">{weightLbs} lbs</strong></span>
                    <span>({Math.round(weightLbs * 0.453592)} kg)</span>
                  </div>
                  <input
                    id="bmi-weight-lbs"
                    type="range"
                    min="80"
                    max="400"
                    value={weightLbs}
                    onChange={(e) => setWeightLbs(Number(e.target.value))}
                    className="w-full h-2 bg-black rounded-lg appearance-none cursor-pointer accent-[#CCFF00]"
                  />
                </div>
              )}
            </div>

            {/* Activity Level Selector */}
            <div className="space-y-2">
              <label className="text-xs font-black text-neutral-300 uppercase tracking-wider block">
                Activity Level
              </label>
              <select
                id="bmi-activity-select"
                value={activityLevel}
                onChange={(e) => setActivityLevel(Number(e.target.value))}
                className="w-full bg-black border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white font-bold focus:border-[#CCFF00] focus:outline-none"
              >
                <option value={1.2}>Sedentary (Desk job, little to no exercise)</option>
                <option value={1.375}>Lightly Active (Gym 1-3 days/week)</option>
                <option value={1.55}>Moderately Active (Studio training sessions 3-5 days/week)</option>
                <option value={1.725}>Very Active (Hard training 6-7 days/week)</option>
                <option value={1.9}>Elite Athlete (2x heavy sessions/day)</option>
              </select>
            </div>
          </div>

          {/* Results Diagnostic Card */}
          <div className="lg:col-span-6 bg-[#141414] border border-neutral-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl space-y-6">
            <div className="space-y-6">
              {/* BMI Score Display */}
              <div className="p-6 rounded-2xl bg-black border border-neutral-800 text-center space-y-3">
                <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">
                  Calculated Body Mass Index
                </span>
                <div className="flex items-center justify-center gap-3">
                  <span className="font-heading text-6xl sm:text-7xl font-black text-white tracking-tight">
                    {bmi}
                  </span>
                  <div className="text-left">
                    <span className="text-xs text-neutral-400 uppercase font-black block">Status</span>
                    <span className={`text-sm font-black uppercase ${bmiDetails.color}`}>
                      {bmiDetails.category}
                    </span>
                  </div>
                </div>

                {/* Visual Progress Scale Bar */}
                <div className="space-y-1.5 pt-2">
                  <div className="w-full h-3 rounded-full bg-neutral-900 overflow-hidden flex border border-neutral-800">
                    <div className="w-[25%] bg-cyan-500/80" title="Underweight (< 18.5)"></div>
                    <div className="w-[30%] bg-[#CCFF00]" title="Normal (18.5 - 24.9)"></div>
                    <div className="w-[25%] bg-amber-500/80" title="Overweight (25.0 - 29.9)"></div>
                    <div className="w-[20%] bg-red-500/80" title="Obese (≥ 30.0)"></div>
                  </div>
                  <div className="flex justify-between text-[10px] text-neutral-400 font-mono px-1 font-bold">
                    <span>16.0</span>
                    <span>18.5 (Normal)</span>
                    <span>25.0</span>
                    <span>30.0+</span>
                  </div>
                </div>

                <p className="text-xs text-neutral-300 leading-relaxed pt-2 font-medium">
                  {bmiDetails.description}
                </p>
              </div>

              {/* Metabolism & TDEE Stat Highlights */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-black border border-neutral-800 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-neutral-300 font-black uppercase">
                    <Flame className="w-4 h-4 text-[#CCFF00] fill-[#CCFF00]" /> Daily Burn (TDEE)
                  </div>
                  <p className="font-heading text-3xl font-black text-white font-mono">
                    {tdee} <span className="text-xs font-normal text-neutral-400">kcal/day</span>
                  </p>
                  <p className="text-[10px] text-neutral-400 font-medium">Maintenance baseline calories</p>
                </div>

                <div className="p-4 rounded-2xl bg-black border border-neutral-800 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-neutral-300 font-black uppercase">
                    <Heart className="w-4 h-4 text-red-500 fill-red-500" /> Healthy Weight
                  </div>
                  <p className="font-heading text-2xl font-black text-white font-mono">
                    {unitSystem === 'metric'
                       ? `${minHealthyKg} - ${maxHealthyKg} kg`
                      : `${Math.round(minHealthyKg * 2.20462)} - ${Math.round(maxHealthyKg * 2.20462)} lbs`}
                  </p>
                  <p className="text-[10px] text-neutral-400 font-medium">Target medical BMI range</p>
                </div>
              </div>

              {/* Recommended Program */}
              <div className="p-4 rounded-2xl bg-black border border-[#CCFF00]/40 flex items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] font-black uppercase text-[#CCFF00]">
                    Recommended Studio Track
                  </span>
                  <h4 className="text-sm font-black text-white uppercase">{bmiDetails.recommendedProg}</h4>
                </div>
                <button
                  onClick={() => {
                    const prog = programs.find((p) => p.title.toLowerCase().includes(bmiDetails.recommendedProg.toLowerCase())) || programs[0];
                    setSelectedProgramForModal(prog);
                  }}
                  className="px-4 py-2 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black text-xs font-black uppercase transition-colors cursor-pointer"
                >
                  View Track
                </button>
              </div>
            </div>

            {/* Save to Profile Button */}
            {currentUser && (
              <button
                id="bmi-save-to-profile-btn"
                onClick={handleSaveToProfile}
                className="w-full py-3 rounded-xl bg-[#1F1F1F] hover:bg-neutral-800 text-white text-xs font-black uppercase tracking-wider transition-colors flex items-center justify-center gap-2 border border-neutral-700 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4 text-[#CCFF00]" />
                <span>Save Metrics to Member Profile</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
