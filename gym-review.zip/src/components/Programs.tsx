import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import {
  Flame,
  Dumbbell,
  Clock,
  Layers,
  Award,
  CheckCircle2
} from 'lucide-react';

export const Programs: React.FC = () => {
  const { programs, setSelectedProgramForModal, setSelectedClassForBooking, schedule } = useGym();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedLevel, setSelectedLevel] = useState<string>('All');

  const categories = [
    'All',
    'Strength',
    'Weight',
    'Cardio',
    'Muscle',
    'Weight Management',
    'Functional',
    'Personal',
    'Group'
  ];

  const levels = ['All', 'Beginner', 'Intermediate', 'Advanced'];

  const filteredPrograms = programs.filter((p) => {
    const matchCat = selectedCategory === 'All' || p.category === selectedCategory;
    const matchLevel = selectedLevel === 'All' || p.level === selectedLevel || p.level === 'All Levels';
    return matchCat && matchLevel;
  });

  const getLevelBadgeClass = (level: string) => {
    switch (level) {
      case 'Beginner':
        return 'bg-emerald-950/80 text-emerald-300 border-emerald-700/60';
      case 'Intermediate':
        return 'bg-neutral-900 text-[#CCFF00] border-[#CCFF00]/40';
      case 'Advanced':
        return 'bg-red-950/80 text-red-300 border-red-700/60';
      default:
        return 'bg-neutral-800 text-neutral-200 border-neutral-700';
    }
  };

  return (
    <section id="programs" className="py-24 bg-[#0A0A0A] border-t border-neutral-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141414] border border-[#CCFF00]/40">
              <Dumbbell className="w-4 h-4 text-[#CCFF00]" />
              <span className="text-xs font-black uppercase tracking-widest text-[#CCFF00]">
                ENGINEERED PERFORMANCE TRACKS
              </span>
            </div>
            <h2 className="font-heading text-4xl sm:text-5xl lg:text-7xl font-black uppercase text-white tracking-tight leading-none">
              TRANSFORMATIVE <span className="text-[#CCFF00]">TRAINING PROGRAMS</span>
            </h2>
            <p className="text-neutral-300 text-sm sm:text-base">
              Each program follows progressive overload principles designed by master coaches.
              Select a discipline to elevate your power, endurance, or muscle composition.
            </p>
          </div>

          {/* Quick Stats Pill */}
          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-[#141414] border border-neutral-800 self-start md:self-auto">
            <div className="w-10 h-10 rounded-xl bg-[#1F1F1F] border border-[#CCFF00]/40 flex items-center justify-center text-[#CCFF00]">
              <Flame className="w-5 h-5 fill-[#CCFF00]" />
            </div>
            <div>
              <p className="text-xs font-black text-white uppercase">{programs.length} Active Tracks</p>
              <p className="text-[11px] text-neutral-400 font-medium">Tailored for Every Fitness Level</p>
            </div>
          </div>
        </div>

        {/* Filters Bar */}
        <div className="space-y-4 mb-10">
          {/* Category Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {categories.map((cat) => (
              <button
                key={cat}
                id={`program-filter-${cat.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider whitespace-nowrap transition-all duration-200 cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#CCFF00] text-black shadow-lg shadow-[#CCFF00]/20'
                    : 'bg-[#141414] text-neutral-400 hover:text-white border border-neutral-800 hover:border-neutral-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Level Filter secondary toggle */}
          <div className="flex items-center gap-3 text-xs text-neutral-400">
            <span className="font-bold uppercase tracking-wider text-neutral-400">Level:</span>
            <div className="flex items-center gap-1.5">
              {levels.map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setSelectedLevel(lvl)}
                  className={`px-3 py-1 rounded-lg transition-colors cursor-pointer font-bold text-xs uppercase ${
                    selectedLevel === lvl
                      ? 'bg-[#1F1F1F] text-[#CCFF00] border border-[#CCFF00]/50'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Programs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredPrograms.map((prog) => (
            <div
              key={prog.id}
              id={`program-card-${prog.id}`}
              className="rounded-3xl bg-[#141414] border border-neutral-800 hover:border-[#CCFF00]/60 transition-all duration-300 flex flex-col justify-between overflow-hidden group shadow-xl hover:shadow-[#CCFF00]/10 hover:-translate-y-1"
            >
              {/* Program Image Header with Overlay */}
              <div className="relative h-48 sm:h-52 overflow-hidden">
                <img
                  src={prog.image}
                  alt={prog.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/40 to-transparent" />

                {/* Level & Category Badges */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                  <span
                    className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border backdrop-blur-md ${getLevelBadgeClass(
                      prog.level
                    )}`}
                  >
                    {prog.level}
                  </span>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-black/80 text-[#CCFF00] border border-neutral-800 backdrop-blur-md">
                    {prog.category}
                  </span>
                </div>

                {/* Duration & Burn metrics bar */}
                <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-[11px] font-bold text-neutral-300 bg-black/80 backdrop-blur-md px-2.5 py-1.5 rounded-lg border border-neutral-800/80">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#CCFF00]" />
                    <span>{prog.sessionDurationMins} min</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-[#CCFF00]" />
                    <span>{prog.caloriesBurnEstimate}</span>
                  </div>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <h3 className="font-heading text-2xl font-black uppercase text-white tracking-tight group-hover:text-[#CCFF00] transition-colors">
                    {prog.title}
                  </h3>
                  <p className="text-xs text-neutral-300 line-clamp-2 leading-relaxed">
                    {prog.description}
                  </p>
                </div>

                {/* Coach info */}
                <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-[#CCFF00] shrink-0" />
                    <div>
                      <p className="font-black text-neutral-200 text-[11px] uppercase">{prog.trainerName}</p>
                      <p className="text-[10px] text-neutral-400">{prog.trainerRole}</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-black text-[#CCFF00] uppercase">
                    {prog.durationWeeks} Wk Cycle
                  </span>
                </div>

                {/* Key Benefits Preview */}
                <div className="space-y-1.5 pt-1">
                  {prog.benefits.slice(0, 2).map((b, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-[11px] text-neutral-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#CCFF00] shrink-0 mt-0.5" />
                      <span className="truncate">{b}</span>
                    </div>
                  ))}
                </div>

                {/* Buttons */}
                <div className="pt-2 grid grid-cols-2 gap-2">
                  <button
                    id={`prog-learn-more-${prog.id}`}
                    onClick={() => setSelectedProgramForModal(prog)}
                    className="w-full py-2.5 rounded-xl bg-[#1F1F1F] hover:bg-neutral-800 text-white text-xs font-black uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    Learn More
                  </button>
                  <button
                    id={`prog-book-${prog.id}`}
                    onClick={() => {
                      const matchingClass = schedule.find((c) =>
                        c.category.toLowerCase().includes(prog.category.toLowerCase()) ||
                        c.title.toLowerCase().includes(prog.category.toLowerCase())
                      ) || schedule[0];
                      if (matchingClass) {
                        setSelectedClassForBooking(matchingClass);
                      }
                    }}
                    className="w-full py-2.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer shadow-md shadow-[#CCFF00]/15"
                  >
                    <span>Book Session</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredPrograms.length === 0 && (
          <div className="text-center py-16 bg-[#141414] rounded-3xl border border-neutral-800 space-y-3">
            <Layers className="w-12 h-12 text-neutral-600 mx-auto" />
            <h3 className="text-lg font-bold text-white uppercase">No Programs in this filter</h3>
            <p className="text-xs text-neutral-400">Try switching categories or view all tracks.</p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSelectedLevel('All');
              }}
              className="px-4 py-2 rounded-xl bg-[#CCFF00] text-black font-black text-xs uppercase cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
