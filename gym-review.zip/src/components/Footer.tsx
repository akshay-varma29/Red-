import React, { useState } from 'react';
import { useGym } from '../context/GymContext';
import {
  Star,
  Instagram,
  Facebook,
  Youtube,
  Send,
  CheckCircle2
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { gymInfo, addToast } = useGym();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setSubscribed(true);
    addToast('Subscribed!', 'You will receive weekly training protocols and fitness nutrition tips.', 'success');
    setNewsletterEmail('');
    setTimeout(() => setSubscribed(false), 4000);
  };

  return (
    <footer className="bg-black border-t border-neutral-800 pt-16 pb-12 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-neutral-800">
          {/* Col 1: Brand & Bio (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#CCFF00] flex items-center justify-center shadow-lg shadow-[#CCFF00]/20">
                <Star className="w-6 h-6 text-black fill-black" />
              </div>
              <div className="flex flex-col">
                <span className="font-heading text-2xl sm:text-3xl font-black tracking-wider text-white">
                  STAR FITNESS STUDIO
                </span>
                <span className="text-[9px] uppercase font-black tracking-[0.25em] text-[#CCFF00] -mt-1">
                  PREMIER ATHLETIC PERFORMANCE
                </span>
              </div>
            </div>

            <p className="text-neutral-300 text-xs leading-relaxed max-w-sm font-medium">
              {gymInfo.tagline} Designed for athletes and everyday fitness warriors seeking championship equipment, master coaching, and an empowering atmosphere.
            </p>

            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href={`https://${gymInfo.instagram}`}
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-xl bg-[#141414] hover:bg-[#CCFF00] hover:text-black text-white flex items-center justify-center border border-neutral-800 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={`https://${gymInfo.facebook}`}
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-xl bg-[#141414] hover:bg-[#CCFF00] hover:text-black text-white flex items-center justify-center border border-neutral-800 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href={`https://${gymInfo.youtube}`}
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-xl bg-[#141414] hover:bg-[#CCFF00] hover:text-black text-white flex items-center justify-center border border-neutral-800 transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-heading text-lg font-black uppercase tracking-wider text-white">
              Navigation
            </h4>
            <ul className="space-y-2 font-bold uppercase text-[11px]">
              <li>
                <a href="#about" className="hover:text-[#CCFF00] transition-colors">
                  About the Studio
                </a>
              </li>
              <li>
                <a href="#programs" className="hover:text-[#CCFF00] transition-colors">
                  Training Programs
                </a>
              </li>
              <li>
                <a href="#trainers" className="hover:text-[#CCFF00] transition-colors">
                  Master Trainers
                </a>
              </li>
              <li>
                <a href="#membership" className="hover:text-[#CCFF00] transition-colors">
                  Membership Plans
                </a>
              </li>
              <li>
                <a href="#schedule" className="hover:text-[#CCFF00] transition-colors">
                  Class Schedule
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Tools & Amenities (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-heading text-lg font-black uppercase tracking-wider text-white">
              Studio Features
            </h4>
            <ul className="space-y-2 font-bold uppercase text-[11px]">
              <li>
                <a href="#calculator" className="hover:text-[#CCFF00] transition-colors">
                  BMI & TDEE Calculator
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#CCFF00] transition-colors">
                  Facility Tour & Success Stories
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#CCFF00] transition-colors">
                  Book Complimentary Day Pass
                </a>
              </li>
              <li className="text-neutral-500">
                <span>Infrared Sauna & Cold Plunge</span>
              </li>
              <li className="text-neutral-500">
                <span>Biomechanical Arsenal Machines</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Newsletter Signup (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-heading text-lg font-black uppercase tracking-wider text-white">
              Star Studio Intel
            </h4>
            <p className="text-xs text-neutral-300 font-medium">
              Get weekly science-based training splits, nutrition recipes, and class schedule updates.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-2 pt-1">
              <div className="flex items-center gap-2">
                <input
                  type="email"
                  required
                  placeholder="Enter your email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="w-full bg-[#141414] border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:border-[#CCFF00] focus:outline-none font-medium"
                />
                <button
                  type="submit"
                  className="p-2.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-bold transition-colors cursor-pointer shrink-0"
                  aria-label="Subscribe to newsletter"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
              {subscribed && (
                <p className="text-[11px] text-[#CCFF00] font-black flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Subscribed successfully!
                </p>
              )}
            </form>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <p>© {new Date().getFullYear()} Star Fitness Studio LLC. All rights reserved.</p>
          <div className="flex items-center gap-6 font-bold uppercase text-[11px]">
            <span className="hover:text-[#CCFF00] cursor-pointer transition-colors">Privacy Policy</span>
            <span className="hover:text-[#CCFF00] cursor-pointer transition-colors">Terms of Service</span>
            <span className="hover:text-[#CCFF00] cursor-pointer transition-colors">Gym Rules & Etiquette</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
