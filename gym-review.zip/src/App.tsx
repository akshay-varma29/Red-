import React from 'react';
import { GymProvider } from './context/GymContext';
import { Toast } from './components/Toast';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Programs } from './components/Programs';
import { Trainers } from './components/Trainers';
import { Membership } from './components/Membership';
import { Schedule } from './components/Schedule';
import { BmiCalculator } from './components/BmiCalculator';
import { Gallery } from './components/Gallery';
import { Testimonials } from './components/Testimonials';
import { ContactLocation } from './components/ContactLocation';
import { Footer } from './components/Footer';

// Interactive Modals & Dashboards
import { AuthModal } from './components/AuthModal';
import { ProgramModal } from './components/ProgramModal';
import { TrainerBookingModal } from './components/TrainerBookingModal';
import { CheckoutModal } from './components/CheckoutModal';
import { UserDashboard } from './components/UserDashboard';
import { AdminDashboard } from './components/AdminDashboard';

export function StarFitnessApp() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] text-neutral-100 font-sans selection:bg-[#CCFF00] selection:text-black antialiased overflow-x-hidden">
      {/* Global Toast System */}
      <Toast />

      {/* Sticky Navigation Bar */}
      <Navbar />

      {/* Main Content Sections */}
      <main>
        <Hero />
        <About />
        <Programs />
        <Trainers />
        <Membership />
        <Schedule />
        <BmiCalculator />
        <Gallery />
        <Testimonials />
        <ContactLocation />
      </main>

      {/* Site Footer */}
      <Footer />

      {/* Interactive Overlays & Portals */}
      <AuthModal />
      <ProgramModal />
      <TrainerBookingModal />
      <CheckoutModal />
      <UserDashboard />
      <AdminDashboard />
    </div>
  );
}

export default function App() {
  return (
    <GymProvider>
      <StarFitnessApp />
    </GymProvider>
  );
}
