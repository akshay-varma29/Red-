import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import confetti from 'canvas-confetti';
import {
  Program,
  Trainer,
  MembershipPlan,
  ClassScheduleItem,
  GalleryItem,
  Testimonial,
  ContactMessage,
  GymInfo,
  User,
  Booking
} from '../types';
import {
  INITIAL_GYM_INFO,
  INITIAL_PROGRAMS,
  INITIAL_TRAINERS,
  INITIAL_MEMBERSHIPS,
  INITIAL_SCHEDULE,
  INITIAL_GALLERY,
  INITIAL_TESTIMONIALS,
  INITIAL_MESSAGES,
  DEMO_USERS,
  INITIAL_BOOKINGS
} from '../data/initialData';

export interface ToastMessage {
  id: string;
  title: string;
  description: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

interface GymContextType {
  // Gym data
  gymInfo: GymInfo;
  programs: Program[];
  trainers: Trainer[];
  membershipPlans: MembershipPlan[];
  schedule: ClassScheduleItem[];
  gallery: GalleryItem[];
  testimonials: Testimonial[];
  messages: ContactMessage[];
  bookings: Booking[];
  members: User[];

  // Auth & Profile
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  loginAs: (role: 'member' | 'admin') => void;
  registerUser: (name: string, email: string, phone: string, goal: string) => User;
  logout: () => void;
  updateUserProfile: (updates: Partial<User>) => void;

  // User Actions
  joinMembership: (planId: string, billingCycle: 'monthly' | 'annual') => boolean;
  cancelMembership: () => void;
  bookClass: (classId: string, bookingDate?: string) => { success: boolean; message: string };
  cancelBooking: (bookingId: string) => void;
  bookTrainerSession: (trainerId: string, date: string, time: string, notes?: string) => { success: boolean; message: string };
  submitContactForm: (data: { name: string; email: string; phone: string; subject: string; message: string }) => boolean;

  // Admin Operations
  addProgram: (program: Omit<Program, 'id'>) => void;
  updateProgram: (id: string, program: Partial<Program>) => void;
  deleteProgram: (id: string) => void;
  addTrainer: (trainer: Omit<Trainer, 'id'>) => void;
  updateTrainer: (id: string, trainer: Partial<Trainer>) => void;
  deleteTrainer: (id: string) => void;
  addClassSchedule: (item: Omit<ClassScheduleItem, 'id' | 'bookedSeats'>) => void;
  updateClassSchedule: (id: string, item: Partial<ClassScheduleItem>) => void;
  deleteClassSchedule: (id: string) => void;
  updateMembershipPlan: (id: string, updates: Partial<MembershipPlan>) => void;
  updateGymInfo: (info: Partial<GymInfo>) => void;
  markMessageStatus: (id: string, status: 'unread' | 'read' | 'replied', replyNotes?: string) => void;
  deleteMessage: (id: string) => void;
  updateMemberStatus: (userId: string, status: 'active' | 'inactive' | 'expired', planId?: string) => void;

  // Toasts
  toasts: ToastMessage[];
  addToast: (title: string, description: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  removeToast: (id: string) => void;

  // Modals & Navigation triggers
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isDashboardOpen: boolean;
  setIsDashboardOpen: (open: boolean) => void;
  isAdminDashboardOpen: boolean;
  setIsAdminDashboardOpen: (open: boolean) => void;
  selectedProgramForModal: Program | null;
  setSelectedProgramForModal: (program: Program | null) => void;
  selectedTrainerForBooking: Trainer | null;
  setSelectedTrainerForBooking: (trainer: Trainer | null) => void;
  selectedPlanForCheckout: MembershipPlan | null;
  setSelectedPlanForCheckout: (plan: MembershipPlan | null) => void;
  selectedClassForBooking: ClassScheduleItem | null;
  setSelectedClassForBooking: (item: ClassScheduleItem | null) => void;
}

const GymContext = createContext<GymContextType | undefined>(undefined);

export const GymProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Load initial from localStorage or defaults
  const [gymInfo, setGymInfo] = useState<GymInfo>(() => {
    const saved = localStorage.getItem('sfs_gym_info');
    return saved ? JSON.parse(saved) : INITIAL_GYM_INFO;
  });

  const [programs, setPrograms] = useState<Program[]>(() => {
    const saved = localStorage.getItem('sfs_programs');
    return saved ? JSON.parse(saved) : INITIAL_PROGRAMS;
  });

  const [trainers, setTrainers] = useState<Trainer[]>(() => {
    const saved = localStorage.getItem('sfs_trainers');
    return saved ? JSON.parse(saved) : INITIAL_TRAINERS;
  });

  const [membershipPlans, setMembershipPlans] = useState<MembershipPlan[]>(() => {
    const saved = localStorage.getItem('sfs_memberships');
    return saved ? JSON.parse(saved) : INITIAL_MEMBERSHIPS;
  });

  const [schedule, setSchedule] = useState<ClassScheduleItem[]>(() => {
    const saved = localStorage.getItem('sfs_schedule');
    return saved ? JSON.parse(saved) : INITIAL_SCHEDULE;
  });

  const [gallery] = useState<GalleryItem[]>(INITIAL_GALLERY);
  const [testimonials] = useState<Testimonial[]>(INITIAL_TESTIMONIALS);

  const [messages, setMessages] = useState<ContactMessage[]>(() => {
    const saved = localStorage.getItem('sfs_messages');
    return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
  });

  const [bookings, setBookings] = useState<Booking[]>(() => {
    const saved = localStorage.getItem('sfs_bookings');
    return saved ? JSON.parse(saved) : INITIAL_BOOKINGS;
  });

  const [members, setMembers] = useState<User[]>(() => {
    const saved = localStorage.getItem('sfs_members');
    return saved ? JSON.parse(saved) : DEMO_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('sfs_current_user');
    return saved ? JSON.parse(saved) : DEMO_USERS[0]; // Default to Demo Member
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Modal states
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);
  const [isAdminDashboardOpen, setIsAdminDashboardOpen] = useState(false);
  const [selectedProgramForModal, setSelectedProgramForModal] = useState<Program | null>(null);
  const [selectedTrainerForBooking, setSelectedTrainerForBooking] = useState<Trainer | null>(null);
  const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<MembershipPlan | null>(null);
  const [selectedClassForBooking, setSelectedClassForBooking] = useState<ClassScheduleItem | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('sfs_gym_info', JSON.stringify(gymInfo));
  }, [gymInfo]);

  useEffect(() => {
    localStorage.setItem('sfs_programs', JSON.stringify(programs));
  }, [programs]);

  useEffect(() => {
    localStorage.setItem('sfs_trainers', JSON.stringify(trainers));
  }, [trainers]);

  useEffect(() => {
    localStorage.setItem('sfs_memberships', JSON.stringify(membershipPlans));
  }, [membershipPlans]);

  useEffect(() => {
    localStorage.setItem('sfs_schedule', JSON.stringify(schedule));
  }, [schedule]);

  useEffect(() => {
    localStorage.setItem('sfs_messages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('sfs_bookings', JSON.stringify(bookings));
  }, [bookings]);

  useEffect(() => {
    localStorage.setItem('sfs_members', JSON.stringify(members));
  }, [members]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('sfs_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('sfs_current_user');
    }
  }, [currentUser]);

  // Toast Helper
  const addToast = (title: string, description: string, type: 'success' | 'info' | 'warning' | 'error' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Auth Operations
  const loginAs = (role: 'member' | 'admin') => {
    const targetUser = members.find((m) => m.role === role) || (role === 'admin' ? DEMO_USERS[1] : DEMO_USERS[0]);
    setCurrentUser(targetUser);
    setIsAuthModalOpen(false);
    addToast(
      'Welcome Back!',
      `Logged in as ${targetUser.name} (${role === 'admin' ? 'Admin / Staff' : 'Active Member'})`,
      'success'
    );
  };

  const registerUser = (name: string, email: string, phone: string, goal: string): User => {
    const newUser: User = {
      id: `user-${Date.now()}`,
      name,
      email,
      role: 'member',
      phone: phone || '+91 98765 00000',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=400&auto=format&fit=crop',
      membershipPlanId: null,
      membershipPlanName: null,
      membershipStatus: 'inactive',
      membershipRenewsAt: null,
      memberSince: new Date().toISOString().split('T')[0],
      qrCode: `SFS-${Math.floor(100000 + Math.random() * 900000)}`,
      fitnessGoal: goal || 'Build Strength & Improve Stamina'
    };
    setMembers((prev) => [newUser, ...prev]);
    setCurrentUser(newUser);
    setIsAuthModalOpen(false);
    addToast(
      'Account Created!',
      `Welcome to Star Fitness Studio, ${name}! Explore our membership passes or book a trial.`,
      'success'
    );
    return newUser;
  };

  const logout = () => {
    setCurrentUser(null);
    setIsDashboardOpen(false);
    setIsAdminDashboardOpen(false);
    addToast('Signed Out', 'You have been successfully signed out.', 'info');
  };

  const updateUserProfile = (updates: Partial<User>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...updates };
    setCurrentUser(updated);
    setMembers((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
    addToast('Profile Updated', 'Your personal metrics and details have been saved.', 'success');
  };

  // Membership Joining
  const joinMembership = (planId: string, billingCycle: 'monthly' | 'annual') => {
    const plan = membershipPlans.find((p) => p.id === planId);
    if (!plan) return false;

    let user = currentUser;
    if (!user) {
      user = registerUser('New Fitness Member', 'member@example.com', '+1 (555) 123-4567', 'Overall Conditioning');
    }

    const renewsDate = new Date();
    if (billingCycle === 'annual') {
      renewsDate.setFullYear(renewsDate.getFullYear() + 1);
    } else {
      renewsDate.setMonth(renewsDate.getMonth() + 1);
    }

    const updatedUser: User = {
      ...user,
      membershipPlanId: plan.id,
      membershipPlanName: `${plan.name} Plan (${billingCycle === 'annual' ? 'Annual Pass' : 'Monthly'})`,
      membershipStatus: 'active',
      membershipRenewsAt: renewsDate.toISOString().split('T')[0]
    };

    setCurrentUser(updatedUser);
    setMembers((prev) => prev.map((m) => (m.id === updatedUser.id ? updatedUser : m)));

    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // safe fallback
    }

    addToast(
      'Membership Activated!',
      `You are now a ${plan.name} Member! Your 24/7 digital keycard pass is ready in your Member Portal.`,
      'success'
    );
    setSelectedPlanForCheckout(null);
    return true;
  };

  const cancelMembership = () => {
    if (!currentUser) return;
    const updatedUser: User = {
      ...currentUser,
      membershipStatus: 'expired'
    };
    setCurrentUser(updatedUser);
    setMembers((prev) => prev.map((m) => (m.id === updatedUser.id ? updatedUser : m)));
    addToast('Membership Modified', 'Your membership will lapse at the end of the billing cycle.', 'warning');
  };

  // Class Booking
  const bookClass = (classId: string, bookingDate?: string): { success: boolean; message: string } => {
    const targetClass = schedule.find((c) => c.id === classId);
    if (!targetClass) {
      return { success: false, message: 'Class not found' };
    }

    if (targetClass.bookedSeats >= targetClass.maxSeats) {
      addToast('Class Full', 'This class is currently at maximum capacity. Try another time slot or join the waitlist.', 'warning');
      return { success: false, message: 'Class is full' };
    }

    if (!currentUser) {
      setIsAuthModalOpen(true);
      return { success: false, message: 'Please log in to reserve your spot' };
    }

    const existing = bookings.find(
      (b) => b.userId === currentUser.id && b.itemId === classId && b.status === 'confirmed'
    );
    if (existing) {
      addToast('Already Reserved', `You already have a reserved spot for ${targetClass.title}.`, 'info');
      return { success: false, message: 'Already reserved' };
    }

    const chosenDate = bookingDate || new Date().toISOString().split('T')[0];

    const newBooking: Booking = {
      id: `book-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      type: 'class',
      itemId: targetClass.id,
      itemTitle: targetClass.title,
      trainerName: targetClass.trainerName,
      day: targetClass.day,
      date: chosenDate,
      time: targetClass.startTime,
      room: targetClass.room,
      status: 'confirmed',
      createdAt: new Date().toISOString()
    };

    setSchedule((prev) =>
      prev.map((c) => (c.id === classId ? { ...c, bookedSeats: c.bookedSeats + 1 } : c))
    );

    setBookings((prev) => [newBooking, ...prev]);

    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch {
      // safe fallback
    }

    addToast(
      'Spot Confirmed!',
      `You're booked for ${targetClass.title} on ${targetClass.day} at ${targetClass.startTime} (${targetClass.room}).`,
      'success'
    );
    setSelectedClassForBooking(null);
    return { success: true, message: 'Class booked successfully' };
  };

  const cancelBooking = (bookingId: string) => {
    const booking = bookings.find((b) => b.id === bookingId);
    if (!booking) return;

    if (booking.type === 'class') {
      setSchedule((prev) =>
        prev.map((c) => (c.id === booking.itemId ? { ...c, bookedSeats: Math.max(0, c.bookedSeats - 1) } : c))
      );
    }

    setBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, status: 'cancelled' } : b))
    );
    addToast('Booking Cancelled', `Your reservation for ${booking.itemTitle} has been cancelled.`, 'info');
  };

  // Trainer Booking
  const bookTrainerSession = (
    trainerId: string,
    date: string,
    time: string,
    notes?: string
  ): { success: boolean; message: string } => {
    const trainer = trainers.find((t) => t.id === trainerId);
    if (!trainer) return { success: false, message: 'Trainer not found' };

    let user = currentUser;
    if (!user) {
      setIsAuthModalOpen(true);
      return { success: false, message: 'Please sign in to book a private session' };
    }

    const newBooking: Booking = {
      id: `book-tr-${Date.now()}`,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      type: 'trainer',
      itemId: trainer.id,
      itemTitle: `1-on-1 Session with ${trainer.name}`,
      trainerName: trainer.name,
      date,
      time,
      room: 'Private Coaching Bay 2',
      status: 'confirmed',
      createdAt: new Date().toISOString()
    };

    setBookings((prev) => [newBooking, ...prev]);

    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch {
      // safe fallback
    }

    addToast(
      'Session Reserved!',
      `Confirmed 1-on-1 training with ${trainer.name} on ${date} at ${time}. Check your dashboard for details.`,
      'success'
    );
    setSelectedTrainerForBooking(null);
    return { success: true, message: 'Session booked successfully' };
  };

  // Contact Form Submission
  const submitContactForm = (data: {
    name: string;
    email: string;
    phone: string;
    subject: string;
    message: string;
  }) => {
    const newMsg: ContactMessage = {
      id: `msg-${Date.now()}`,
      name: data.name,
      email: data.email,
      phone: data.phone,
      subject: data.subject,
      message: data.message,
      date: new Date().toISOString().split('T')[0],
      status: 'unread'
    };
    setMessages((prev) => [newMsg, ...prev]);
    addToast(
      'Message Received!',
      `Thank you ${data.name}. A Star Fitness Studio master trainer will reach out shortly.`,
      'success'
    );
    return true;
  };

  // Admin Program CRUD
  const addProgram = (progData: Omit<Program, 'id'>) => {
    const newProg: Program = {
      ...progData,
      id: `prog-${Date.now()}`
    };
    setPrograms((prev) => [...prev, newProg]);
    addToast('Program Created', `Added ${newProg.title} to studio curriculum.`, 'success');
  };

  const updateProgram = (id: string, updates: Partial<Program>) => {
    setPrograms((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p)));
    addToast('Program Updated', 'Curriculum details have been updated.', 'success');
  };

  const deleteProgram = (id: string) => {
    setPrograms((prev) => prev.filter((p) => p.id !== id));
    addToast('Program Removed', 'The program has been removed from the catalog.', 'info');
  };

  // Admin Trainer CRUD
  const addTrainer = (trainerData: Omit<Trainer, 'id'>) => {
    const newTr: Trainer = {
      ...trainerData,
      id: `tr-${Date.now()}`
    };
    setTrainers((prev) => [...prev, newTr]);
    addToast('Trainer Added', `Welcome ${newTr.name} to the coaching staff!`, 'success');
  };

  const updateTrainer = (id: string, updates: Partial<Trainer>) => {
    setTrainers((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));
    addToast('Trainer Updated', 'Trainer profile credentials updated.', 'success');
  };

  const deleteTrainer = (id: string) => {
    setTrainers((prev) => prev.filter((t) => t.id !== id));
    addToast('Trainer Removed', 'Trainer record removed.', 'info');
  };

  // Admin Schedule CRUD
  const addClassSchedule = (classData: Omit<ClassScheduleItem, 'id' | 'bookedSeats'>) => {
    const newClass: ClassScheduleItem = {
      ...classData,
      id: `sched-${Date.now()}`,
      bookedSeats: 0
    };
    setSchedule((prev) => [...prev, newClass]);
    addToast('Class Scheduled', `New ${newClass.title} session added to ${newClass.day}.`, 'success');
  };

  const updateClassSchedule = (id: string, updates: Partial<ClassScheduleItem>) => {
    setSchedule((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
    addToast('Schedule Updated', 'Class time and capacity updated.', 'success');
  };

  const deleteClassSchedule = (id: string) => {
    setSchedule((prev) => prev.filter((c) => c.id !== id));
    addToast('Class Removed', 'Class removed from the weekly timetable.', 'info');
  };

  // Admin Membership Plan CRUD
  const updateMembershipPlan = (id: string, updates: Partial<MembershipPlan>) => {
    setMembershipPlans((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p)));
    addToast('Plan Updated', 'Membership pricing and benefits updated.', 'success');
  };

  // Gym info updates
  const updateGymInfo = (info: Partial<GymInfo>) => {
    setGymInfo((prev) => ({ ...prev, ...info }));
    addToast('Gym Details Saved', 'Facility hours, address, and contact info updated.', 'success');
  };

  // Messages management
  const markMessageStatus = (id: string, status: 'unread' | 'read' | 'replied', replyNotes?: string) => {
    setMessages((prev) =>
      prev.map((m) => (m.id === id ? { ...m, status, replyNotes: replyNotes || m.replyNotes } : m))
    );
    addToast('Inquiry Status Updated', `Message marked as ${status}.`, 'info');
  };

  const deleteMessage = (id: string) => {
    setMessages((prev) => prev.filter((m) => m.id !== id));
    addToast('Message Deleted', 'Inquiry removed from inbox.', 'info');
  };

  // Member management
  const updateMemberStatus = (userId: string, status: 'active' | 'inactive' | 'expired', planId?: string) => {
    setMembers((prev) =>
      prev.map((m) => {
        if (m.id === userId) {
          const plan = planId ? membershipPlans.find((p) => p.id === planId) : null;
          return {
            ...m,
            membershipStatus: status,
            ...(plan ? { membershipPlanId: plan.id, membershipPlanName: plan.name } : {})
          };
        }
        return m;
      })
    );
    addToast('Member Record Updated', 'Status and access privileges updated.', 'success');
  };

  return (
    <GymContext.Provider
      value={{
        gymInfo,
        programs,
        trainers,
        membershipPlans,
        schedule,
        gallery,
        testimonials,
        messages,
        bookings,
        members,
        currentUser,
        setCurrentUser,
        loginAs,
        registerUser,
        logout,
        updateUserProfile,
        joinMembership,
        cancelMembership,
        bookClass,
        cancelBooking,
        bookTrainerSession,
        submitContactForm,
        addProgram,
        updateProgram,
        deleteProgram,
        addTrainer,
        updateTrainer,
        deleteTrainer,
        addClassSchedule,
        updateClassSchedule,
        deleteClassSchedule,
        updateMembershipPlan,
        updateGymInfo,
        markMessageStatus,
        deleteMessage,
        updateMemberStatus,
        toasts,
        addToast,
        removeToast,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isDashboardOpen,
        setIsDashboardOpen,
        isAdminDashboardOpen,
        setIsAdminDashboardOpen,
        selectedProgramForModal,
        setSelectedProgramForModal,
        selectedTrainerForBooking,
        setSelectedTrainerForBooking,
        selectedPlanForCheckout,
        setSelectedPlanForCheckout,
        selectedClassForBooking,
        setSelectedClassForBooking
      }}
    >
      {children}
    </GymContext.Provider>
  );
};

export const useGym = () => {
  const context = useContext(GymContext);
  if (!context) {
    throw new Error('useGym must be used within a GymProvider');
  }
  return context;
};
